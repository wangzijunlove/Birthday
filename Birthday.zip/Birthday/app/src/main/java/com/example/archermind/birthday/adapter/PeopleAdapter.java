package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.archermind.birthday.R;

import java.util.ArrayList;
import java.util.List;

public class PeopleAdapter extends RecyclerView.Adapter<PeopleAdapter.MyViewHolder> {
    private List<String> list_data = new ArrayList<>();
    private Context mcontext;
    public PeopleAdapter(Context context , List<String> list){
        mcontext = context;
        list_data = list;
    }
    @NonNull
    @Override
    public PeopleAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        final View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.people_item, viewGroup, false);
        PeopleAdapter.MyViewHolder holder = new PeopleAdapter.MyViewHolder(v);
        if (mOnRecyclerViewItemListener != null){
            itemOnClick(holder);
            itemOnLongClick(holder);
        }
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PeopleAdapter.MyViewHolder myViewHolder, int i) {
        myViewHolder.tv_name.setText(list_data.get(i));
        if (i == 4){
            myViewHolder.view.setBackgroundColor( mcontext.getResources().getColor(R.color.white));
            myViewHolder.tv_name.setTextColor( mcontext.getResources().getColor(R.color.red));
            myViewHolder.tv_name.setTextSize(30);
            myViewHolder.tv_name.setGravity(Gravity.CENTER);
        }

    }

    @Override
    public int getItemCount() {
        return list_data.size();
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_name,tv_description;
        private View view;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView.findViewById(R.id.layout_people_item);
            tv_name = itemView.findViewById(R.id.tv_name_people);
            tv_description = itemView.findViewById(R.id.tv_description);
        }
    }

    private void itemOnClick(final PeopleAdapter.MyViewHolder holder){
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, pos);
            }
        });
    }
    private void itemOnLongClick(final PeopleAdapter.MyViewHolder holder){
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemLongClickListener(holder.itemView, pos);
                return true;
                //  return mOnRecyclerViewItemListener.onItemLongClickListener(v, v.getTag());
                //返回true是为了防止触发onClick事件
            }
        });
    }
    public interface OnRecyclerViewItemListener {
        public void onItemClickListener(View view, int position);
        public void onItemLongClickListener(View view, int position);
    }

    private PhotoAdapter.OnRecyclerViewItemListener mOnRecyclerViewItemListener;

    public void setOnRecyclerViewItemListener(PhotoAdapter.OnRecyclerViewItemListener listener){
        mOnRecyclerViewItemListener = listener;
    }
}
