package com.example.archermind.birthday.util;

import android.content.Context;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.util.Log;

import java.util.ArrayList;

public class MusicUtils {
    private static final String TAG = "TAG";
    private static ArrayList<Music> list = new ArrayList<>();
    private Context mcontext;
    private boolean flag=true;
    public  ArrayList<Music> getMusic(Context context) {
                mcontext=context;
                RingtoneManager manager = new RingtoneManager(mcontext);
                manager.setType(RingtoneManager.TYPE_ALARM);
                Cursor cursor = manager.getCursor();
                Log.e("MusicUtils", "thread run");
                if (cursor.moveToFirst()) {
                    while (cursor.moveToNext()) {
                        String ringName = manager.getRingtone(cursor.getPosition()).getTitle(mcontext);
                        String ringPath = manager.getRingtoneUri(cursor.getPosition()).toString();
                        Music music = new Music(ringName,ringPath);
                        if(new ListOperation().RemoveRepeat(list, music)){
                            list.add(music);
                        }

                    }
                }
        return list;
    }

}



