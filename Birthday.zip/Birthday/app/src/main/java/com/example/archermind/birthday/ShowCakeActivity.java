package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.util.Utils;

public class ShowCakeActivity extends AppCompatActivity {
    private TextView tv_name,tv_price,tv_title;
    private ImageView img_photo,img_cakephoto;
    private String TAG = "ShowCakeActivity";
    private Button button_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_cake);
        init();
        button_back = findViewById(R.id.show_cake_back);
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void init(){
        tv_name = findViewById(R.id.tv_cake_name);
        tv_price = findViewById(R.id.tv_cake_price);
        tv_title = findViewById(R.id.tv_cake_title);
        img_photo = findViewById(R.id.img_cakephoto);
        img_cakephoto = findViewById(R.id.img_cakecomtent1);

        final Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        int price = intent.getIntExtra("price",-1 );
        String photo = intent.getStringExtra("photo");
        Log.e(TAG,"name = "+name+" price ="+price+" photo ="+photo);
        tv_name.setText(name);
        tv_title.setText(name);
        tv_price.setText("$"+price);
        img_cakephoto.setImageBitmap(Utils.getPhoto(photo));
        img_photo.setImageBitmap(Utils.getPhoto(photo));
    }
}
