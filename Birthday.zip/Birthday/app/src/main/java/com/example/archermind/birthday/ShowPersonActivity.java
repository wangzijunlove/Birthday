package com.example.archermind.birthday;

import android.content.Intent;
import android.nfc.NfcAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.fragment.Fragment3;
import com.example.archermind.birthday.fragment.Fragment4;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;

import java.util.HashMap;
import java.util.Map;


public class ShowPersonActivity extends AppCompatActivity {
    private TextView textView_infomation;
    private NfcAdapter mNfcAdapter;
    private TextView textView_name,textView_signature;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_person);
        textView_infomation = findViewById(R.id.tv_person_information);
        textView_infomation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             startActivity(new Intent(ShowPersonActivity.this,EditPersonActivity.class));

            }
        });
        Map<String, String> userMap = new HashMap<String, String>();
        userMap = getUserInfo();
        textView_name = findViewById(R.id.tv_person_name);
        textView_name.setText(userMap.get("name"));
        textView_signature = findViewById(R.id.tv_person_signature);
        textView_signature.setText(userMap.get("signature"));
    }

    /**
     * 从数据库获取用户的信息
     * @return
     */
    private Map<String,String> getUserInfo(){
        DatabaseManger manger = new DatabaseManger(ShowPersonActivity.this);
        Map<String, String> user = new HashMap<String, String>();
        String sql = "select *from userinfo";
        try {
            user = manger.queryUserinfo(sql, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        manger.close();
        return user;
    }

    /**
     * 手机的按键监听
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent home = new Intent(ShowPersonActivity.this,BottomActivity.class);
            home.putExtra("flag", 3);
            startActivity(home);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
