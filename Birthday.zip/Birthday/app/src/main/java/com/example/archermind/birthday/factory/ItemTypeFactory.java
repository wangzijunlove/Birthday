package com.example.archermind.birthday.factory;

import android.view.View;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.BootomHomeBean;
import com.example.archermind.birthday.bean.ContentBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.bean.ShowdetailGiftBean;
import com.example.archermind.birthday.bean.ShowlistBean;
import com.example.archermind.birthday.bean.Sowingmap;
import com.example.archermind.birthday.viewholder.BannerViewHolder;
import com.example.archermind.birthday.viewholder.BaseViewHolder;
import com.example.archermind.birthday.viewholder.BottomHomeViewHolder;
import com.example.archermind.birthday.viewholder.ContentViewHolder;
import com.example.archermind.birthday.viewholder.RecommendViewHolder;
import com.example.archermind.birthday.viewholder.ShowDetailGiftViewHolder;
import com.example.archermind.birthday.viewholder.ShowlistViewHolder;
import com.example.archermind.birthday.viewholder.SowingmapViewHolder;



public class ItemTypeFactory implements TypeFactory {
    //  将id作为type传入adapter
    public static final int BANNER_ITEM_LAYOUT = R.layout.item_banner_mulittype;
    public static final int CONTENT_ITEM_LAYOUT = R.layout.item_content_mulittype;
    public static final int SOWING_ITEM_LAYOUT = R.layout.turnpicture_item;
    public static final int SHOWLIST_ITEM_LAYOUT = R.layout.main_layout;
    private static final int RECOMMEND_ITEM_LAYOUT = R.layout.home_gift_navigation;
    private static final int BOOTOM_ITEM_LAYOUT = R.layout.home_bottom_item;
    private static final int SHOWDETAILGIFT_ITEM_LAYOUT = R.layout.show_detail_gift_item;

    @Override
    public int type(BannerBean bannerBean) {
        return BANNER_ITEM_LAYOUT;
    }

    @Override
    public int type(ContentBean contentBean) {
        return CONTENT_ITEM_LAYOUT;
    }

    @Override
    public int type(Sowingmap sowingmap) {
        return SOWING_ITEM_LAYOUT;
    }

    public int type(ShowlistBean mainBean) {
        return SHOWLIST_ITEM_LAYOUT;
    }

    public int type(RecommendBean recommendBean) {
        return RECOMMEND_ITEM_LAYOUT;
    }

    @Override
    public int type(BootomHomeBean bootomHomeBean) {
        return BOOTOM_ITEM_LAYOUT;
    }

    @Override
    public int type(ShowdetailGiftBean showdetailGiftBean) {
        return SHOWDETAILGIFT_ITEM_LAYOUT;
    }

    @Override
    public BaseViewHolder createViewHolder(int type, View itemView) {
        switch (type) {
            case BANNER_ITEM_LAYOUT:
                return new BannerViewHolder(itemView);
            case CONTENT_ITEM_LAYOUT:
                return new ContentViewHolder(itemView);
            case SOWING_ITEM_LAYOUT:
                return new SowingmapViewHolder(itemView);
            case SHOWLIST_ITEM_LAYOUT:
                return new ShowlistViewHolder(itemView);
            case RECOMMEND_ITEM_LAYOUT:
                return new RecommendViewHolder(itemView);
            case BOOTOM_ITEM_LAYOUT:
                return new BottomHomeViewHolder(itemView);
            case SHOWDETAILGIFT_ITEM_LAYOUT:
                return new ShowDetailGiftViewHolder(itemView);
            default:
                return null;
        }
    }
}
