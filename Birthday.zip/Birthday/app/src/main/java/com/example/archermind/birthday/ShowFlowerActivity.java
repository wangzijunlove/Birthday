package com.example.archermind.birthday;

import android.app.Instrumentation;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.util.Utils;

public class ShowFlowerActivity extends AppCompatActivity {

    private TextView tv_name,tv_title,tv_price;
    private ImageView img_photo,imageView_photoconent;
    private Button button_back;
    private String TAG = "ShowFlowerActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_flower);
        init();
        button_back = findViewById(R.id.show_flower_back);
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
    }

    private void init(){
        Log.d("-----------------","------------------------");
        tv_name = findViewById(R.id.tv_flower_name);
        tv_price = findViewById(R.id.tv_flower_price);
        tv_title = findViewById(R.id.tv_flower_title);
        img_photo = findViewById(R.id.img_flowerphoto);
        imageView_photoconent = findViewById(R.id.img_flowercomtent1);

        final Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        int price = intent.getIntExtra("price",-1 );
        String photo = intent.getStringExtra("photo");
        Log.e(TAG,"name = "+name+" price ="+price+" photo ="+photo);
        tv_name.setText(name);
        tv_title.setText(name);
        tv_price.setText("$"+price);
        imageView_photoconent.setImageBitmap(Utils.getPhoto(photo));
        img_photo.setImageBitmap(Utils.getPhoto(photo));
    }
}
