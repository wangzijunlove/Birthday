package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import com.example.archermind.birthday.util.Utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText text_name, text_password;
    private TextView btn_login,btn_registered;
    private String name = null;
    private String password = null;
    private Boolean login_status = false;
    OkHttpClient client = new OkHttpClient();
    String url = "http://47.101.209.193:8080/birthday/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
        Login();
    }

    /**
     * 初始化登录的时候判断是否已经登录
     * true 跳转到主界面
     * false  停留在登录界面
     */
    private void initView() {
        text_name = findViewById(R.id.edit_login_name);
        text_password = findViewById(R.id.edit_login_password);
        btn_login = findViewById(R.id.tv_login_login);
        btn_registered =findViewById(R.id.tv_login_registered);
        name = Utils.getUserInfo(LoginActivity.this).get("name");
        password = Utils.getUserInfo(LoginActivity.this).get("password");
        if (Utils.getUserInfo(LoginActivity.this).get("status").equals("已登录")) {
            startActivity(new Intent(LoginActivity.this,BottomActivity.class));
            Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
        }else if(Utils.getUserInfo(LoginActivity.this).get("status").equals("未登录")){
            if (name!=null) {
                text_name.setText(name);
            }
            if (password!=null) {
                text_password.setText(password);
            }
        }


    }

    /**
     * 判断是否登录成功
     * @return
     * true -> login success
     * false -> login failed
     */

    public Boolean Login() {

        btn_registered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, Registered_Activity.class));
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = text_name.getText().toString();
                password = text_password.getText().toString();
               doPost(v);
            }
        });
        return login_status;
    }



    public void doPost(View view) {
        String name = text_name.getText().toString();
        String pass = text_password.getText().toString();
        FormBody formBody = new FormBody.Builder()
                .add("name", name)
                .add("password", pass)
                .build();

        Request.Builder builder = new Request.Builder();
        final Request request = builder.url(url + "LoginAction").post(formBody).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("OkHttpActivity", "访问失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //  Log.e("OKHttpActivity","  "+response.body().string());
                String result = response.body().string();
                Log.e("OKHttpActivity","  "+result);
                Message message = mHandler.obtainMessage();
                message.what = 1;
                message.obj = result;
                mHandler.sendMessage(message);

            }
        });
    }


    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 1){
                String result = msg.obj.toString();
                if (result.equals("nouser")){
                    Toast.makeText(LoginActivity.this, "还没有注册", Toast.LENGTH_SHORT).show();
                }else if (result.equals("success")) {

                        startActivity(new Intent(LoginActivity.this, BottomActivity.class));
                        Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                        login_status = true;
                        Utils.saveUserInfo(LoginActivity.this,name ,password ,true );

                } else {
                    Toast.makeText(LoginActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                    login_status = false;
                }
            }
            super.handleMessage(msg);
        }
    };

    /**
     * 手机的按键的回调方法，实现返回键回到主界面
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            home.addCategory(Intent.CATEGORY_HOME);
            startActivity(home);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
