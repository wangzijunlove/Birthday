package com.example.archermind.birthday.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.Activity01;
import com.example.archermind.birthday.R;
import com.example.archermind.birthday.SearchActivity;
import com.example.archermind.birthday.adapter.GpsHelper;
import com.example.archermind.birthday.adapter.MulitAdpter;
import com.example.archermind.birthday.bean.BootomHomeBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.sqlhepler.DataBaseHelp;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Fragment2 extends Fragment implements View.OnClickListener  {
    private TextView textView_search;
    private TextView textView_lacation;
    private GpsHelper gpsHelper;
    private RecyclerView recyclerView;
    private static  Context mContext;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_second, container, false );
        textView_search  = view.findViewById(R.id.tv_search_main);
        /**
         *点击搜索框，跳转到搜索功能页面
         */
        textView_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),SearchActivity.class));
            }
        });
        init(view);
        mContext = getContext();
        return view;
    }

    public static Context jump(){
        return mContext;
    }

    /**
     * 初始化操作
     * @param view
     */
    private void init( View view){

        gpsHelper = new GpsHelper(getContext(), mHandler);
        textView_lacation = view.findViewById(R.id.tv_city);
        textView_lacation.setText(Utils.getInfo(getContext()).get("address"));
        textView_lacation.setOnClickListener(this);

        recyclerView = view.findViewById(R.id.recy_home);

        List<Recommendedgift>  list_data =new ArrayList<>();
        DatabaseManger manger = new DatabaseManger(getContext());
        String sql = "select *from classification where sort = 'must' ";
        try {
           list_data = manger.queryList(sql, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        manger.close();
        List<Visitable> beans = new ArrayList<>();

//        beans.add(new MainBean());
        beans.add(new RecommendBean(list_data,getContext()));
//        beans.add(new ContentBean());
        beans.add(new BootomHomeBean());
        MulitAdpter multiRecyclerAdapter = new MulitAdpter(beans);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(multiRecyclerAdapter);

//        new Thread(){
//            @Override
//            public void run() {
//                super.run();
//                try {
//                    getBitmap("http://47.101.209.193:8080/birthday/create/t1/a2.jpg");
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    Log.e("--", "--------------------------");
//                }
//            }
//        }.start();
    }




    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_city:
                startActivity(new Intent(getContext(), Activity01.class));
        }

    }

    /**
     *Handler进行对传递的位置信息进行处理
     */
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            int type = msg.what;
            Log.i("BottomActivity", "handleMessage type = " + type);
            switch (type) {
                case 1:
                    try {
                        Map<String, String> map = (Map<String, String>) msg.getData().getSerializable("Address");
                        Log.e(" ------", map.get("Address"));
                        Utils.saveInfo(getContext(), map.get("City"), map.get("Address"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //textView.setText(map.get("City"));
                    gpsHelper.stopScan();
                    break;
                default:
                    Log.d("BottomActivity", "should not get here!!!");
                    break;
            }
        }
    };


}
