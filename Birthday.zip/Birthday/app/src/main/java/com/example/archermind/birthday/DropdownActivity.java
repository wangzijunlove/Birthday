package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DropdownActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerView;
    List<String> list  =new ArrayList<>();
    private String TAG = "DropdownActivity";
    private static final int TYPE_RESTART = 1;
//    private DeleteAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dropdown);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.colorPrimary,
                R.color.green,
                R.color.red
        );
        swipeRefreshLayout.setOnRefreshListener(this);
        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        list.add("00");
//        adapter =new DeleteAdapter(this,list);
//        recyclerView.setAdapter(adapter);
    }
    @Override
    public void onRefresh() {
        // 网络请求
//        okHttp.getHandler(handlerForGenJin);
//        // 这里用sortWay变量 这样即使下拉刷新也能保持用户希望的排序方式
//        askForOkHttp(sortWay);
        for(int i=0;i<addData().size();i++)
        {
            list.add(addData().get(i));
        }


    }
    private List<String> addData(){
        List<String> list=new ArrayList<>();
        for(int i=1;i<=15;i++){
            list.add("姓名"+i);
        }
        mHandler.sendEmptyMessage(TYPE_RESTART);
        return list;
    }


    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            int type = msg.what;
            switch (type) {
                case TYPE_RESTART:
                    Log.e(TAG,"start"+list.size());
                    swipeRefreshLayout.setRefreshing(false);
//                    adapter.notifyDataSetChanged();
                    break;
                default:
                    Log.d(TAG, "should not get here!!!");
                    break;
            }
        }
    };
}
