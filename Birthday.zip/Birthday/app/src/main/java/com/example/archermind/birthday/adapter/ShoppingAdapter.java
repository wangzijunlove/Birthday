package com.example.archermind.birthday.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowShoppingActivity;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShoppingAdapter extends RecyclerView.Adapter<ShoppingAdapter.MyViewHolder> {
    private List<Recommendedgift> list_data = new ArrayList<>();
    private Context mcontext;
    private Map<Integer, Boolean> map = new HashMap<>();
    private String flag;
    public ShoppingAdapter(Context context , List<Recommendedgift> list){
        mcontext = context;
        list_data = list;
        this.flag = ShowShoppingActivity.flag;
    }
    @NonNull
    @Override
    public ShoppingAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        final View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.shopping_item, viewGroup, false);
        ShoppingAdapter.MyViewHolder holder = new ShoppingAdapter.MyViewHolder(v);
        if (mOnRecyclerViewItemListener != null){
            itemOnClick(holder);
            itemOnLongClick(holder);
        }
        return holder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final ShoppingAdapter.MyViewHolder myViewHolder, final int i) {
        Recommendedgift gift  = list_data.get(i);
        myViewHolder.tv_title.setText(gift.getTitle());
        myViewHolder.tv_price.setText("$"+String.valueOf(gift.getPrice()));
        if(flag.equals("shopping")){
            myViewHolder.tv_number.setText("x"+String.valueOf(gift.getShopping()));
        }else {
            myViewHolder.tv_number.setText("x"+String.valueOf(gift.getCollection()));
        }
        myViewHolder.imageView_image.setImageBitmap(gift.getPhoto());
        myViewHolder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                map.put(i,isChecked );
            }
        });
        if (map.get(i) == null) {
            map.put(i, false);
        }
        myViewHolder.checkBox.setChecked(map.get(i));

    }

    @Override
    public int getItemCount() {
        return list_data.size();
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_title,tv_price,tv_number;
        private ImageView  imageView_image;
        private CheckBox checkBox;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_person_shopping_title);
            tv_price = itemView.findViewById(R.id.tv_person_shopping_price);
            tv_number = itemView.findViewById(R.id.tv_person_shopping_number);
            imageView_image = itemView.findViewById(R.id.img_person_shopping_image);
            checkBox = itemView.findViewById(R.id.check_person_shopping);
        }
    }

    private void itemOnClick(final ShoppingAdapter.MyViewHolder holder){
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, pos);
            }
        });
    }
    private void itemOnLongClick(final ShoppingAdapter.MyViewHolder holder){
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemLongClickListener(holder.itemView, pos);
                return true;
                //  return mOnRecyclerViewItemListener.onItemLongClickListener(v, v.getTag());
                //返回true是为了防止触发onClick事件
            }
        });
    }
    public interface OnRecyclerViewItemListener {
        public void onItemClickListener(View view, int position);
        public void onItemLongClickListener(View view, int position);
    }

    private ShoppingAdapter.OnRecyclerViewItemListener mOnRecyclerViewItemListener;

    public void setOnRecyclerViewItemListener(ShoppingAdapter.OnRecyclerViewItemListener listener){
        mOnRecyclerViewItemListener = listener;
    }

    public void setSelectItem(int position) {
        //对当前状态取反
        if (map.get(position)) {
            map.put(position, false);
        } else {
            map.put(position, true);
        }
        notifyItemChanged(position);
    }

    //返回集合给MainActivity
    public Map<Integer, Boolean> getMap() {
        return map;
    }
}
