package com.example.archermind.birthday.viewholder;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowGiftListActivity;
import com.example.archermind.birthday.fragment.Fragment3;

import butterknife.Bind;
import butterknife.ButterKnife;



public class ContentViewHolder extends BaseViewHolder {
  @Bind(R.id.layout1) View view_eat;
  @Bind(R.id.layout2) View view_create;
  @Bind(R.id.layout3) View view_baby;
  @Bind(R.id.layout4) View view_decoration;
  @Bind(R.id.layout5) View view_health;
  @Bind(R.id.layout6) View view_house;
  private Context mContext;
  public ContentViewHolder(View itemView) {
    super(itemView);
    ButterKnife.bind(this, itemView);
  }

  @Override public void bindViewData(Object data) {
    mContext = Fragment3.jump();

    view_eat.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_EAT);
        mContext.startActivity(intent);
      }
    });


    view_create.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_CREATE);
        mContext.startActivity(intent);
      }
    });

    view_baby.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_BABY);
        mContext.startActivity(intent);
      }
    });

    view_decoration.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_DECORATION);
        mContext.startActivity(intent);
      }
    });


    view_health.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_HEALTH);
        mContext.startActivity(intent);
      }
    });

    view_house.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mContext, ShowGiftListActivity.class);
        intent.putExtra("flag", ShowGiftListActivity.TYPE_SHOW_GIFTLIST_HOUSE);
        mContext.startActivity(intent);
      }
    });

  }
}
