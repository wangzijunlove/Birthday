package com.example.archermind.birthday.fragment;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.WelcomeActivity;
import com.example.archermind.birthday.adapter.MulitAdpter;
import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.ContentBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.bean.Sowingmap;
import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Showgift;
import com.example.archermind.birthday.viewholder.BannerViewHolder;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Fragment3 extends Fragment {
    private RecyclerView recyclerView;
    private static Context mContext;
    private TextView tv_birthday;
    List<Recommendedgift> list_data = new ArrayList<>();
    MulitAdpter multiRecyclerAdapter;
    OkHttpClient client = new OkHttpClient();
    String url = "http://47.101.209.193:8080/birthday/";
    private String TAG = "fragment3";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_third, container, false);
        mContext = getContext();
        List<Visitable> beans = new ArrayList<>();
        @SuppressLint("ResourceType") InputStream flower = getResources().openRawResource(R.drawable.sowing);
        Bitmap bb = BitmapFactory.decodeStream(flower);
        tv_birthday = view.findViewById(R.id.fragment3_birthday);
        recyclerView = view.findViewById(R.id.recy_gift);
        beans.add(new Sowingmap(bb, mContext));
        beans.add(new ContentBean());
        beans.add(new BannerBean(list_data, mContext));
        multiRecyclerAdapter = new MulitAdpter(beans);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(multiRecyclerAdapter);
//          //使用AsyncTask进行异步信息加载
        doPost();
        return view;
    }

    public static Context jump() {
        return mContext;
    }

    /*
    public class MyThread extends Thread{
        @Override
        public void run() {
            super.run();
            List<Recommendedgift> list = new ArrayList<>();
            DatabaseManger manger = new DatabaseManger(getContext());

            String sql = "select *from classification where id > 22 ";
            try {
                list = manger.queryList(sql, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            manger.close();
            Message msg = new Message();
            msg.what = 1;
            ArrayList arrayList = new ArrayList();
            arrayList.add(list);
            Bundle b = new Bundle();
            b.putStringArrayList("CLASSIC",  arrayList);
            msg.setData(b);
            // Handler handler=MainActivity.handlerOPeration.getHandler();
            mhandler.sendMessage(msg);
        }
    }
    };
*/
    @SuppressLint("HandlerLeak")
    public Handler mhandler = new Handler() {
        public void handleMessage(Message msg) {
            int i = 0;
            List<Recommendedgift> list1 = new ArrayList<>();
            switch (msg.what) {
                case 1:

                    try {
                        Gson gson = new Gson();
                        Type type = new TypeToken<List<Recommendedgift>>() {
                        }.getType();
                        list1 = gson.fromJson(msg.obj.toString(), type);
                        Log.d("--------", "----------" + list1.get(0).getTitle());
                    } catch (JsonSyntaxException e) {
                        e.printStackTrace();
                    }
                    list_data.addAll(list1);
                    Log.e("--------", "----------" +list_data.size());
                    new SyncData().execute();

//                    ArrayList blueRet = msg.getData().getParcelableArrayList("CLASSIC");
//                    list_data = (List<Recommendedgift>) blueRet.get(0);
//                    @SuppressLint("ResourceType") InputStream flower = getResources().openRawResource(R.drawable.sowing);
//                    Bitmap bb = BitmapFactory.decodeStream(flower);
//                    Log.e("--------------",""+list_data);
//                    List<Visitable> beans = new ArrayList<>();
//                    beans.add(new Sowingmap(bb,mContext));
//                    beans.add(new ContentBean());
//                    beans.add(new BannerBean(list_data,mContext));
////        beans.add(new RecommendBean(list_data,getContext()));
//                    multiRecyclerAdapter = new MulitAdpter(beans);
//                    LinearLayoutManager linearLayoutManager =
//                            new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
//                    recyclerView.setLayoutManager(linearLayoutManager);
//                    recyclerView.setAdapter(multiRecyclerAdapter);
                    break;
                case 2:


                    break;

            }
        }
    };

    public Bitmap getBitmap(String path) throws IOException {
        try {
            URL url = new URL(path);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() == 200) {
                InputStream inputStream = conn.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                Log.d("HttpUrlGetImage", "----------" + bitmap);
                return bitmap;
            }
        } catch (IOException e) { // TODO Auto-generated catch block e.printStackTrace();
        }
        return null;
    }

    public void doPost() {

        Request.Builder builder = new Request.Builder();
        final Request request = builder.url(url + "BirthdayAction").build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("OkHttpActivity", "访问失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String info = response.body().string();
//                info = new String(info.getBytes("utf-8"));
                Log.d("--------", "----------" + info);


                Message message = mhandler.obtainMessage();
                message.what = 1;
                message.obj = info;
                mhandler.sendMessage(message);

            }
        });
    }


    /**
     * 使用AsyncTask进行数据的异步加载，并且通知适配器更新
     */
    private class SyncData extends AsyncTask<Void, Void, List<Recommendedgift>> {

        /**
         * 子线程中进行耗时操作
         *
         * @param voids
         * @return
         */
        @Override
        protected List<Recommendedgift> doInBackground(Void... voids) {
            List<Recommendedgift> list = new ArrayList<>();
            list.addAll(list_data);
            for(int i = 0;i < list.size();i++)
            {
                try {
                    Log.e("--------", "----------" +list.get(i).getImageurl());
                    Bitmap mm = getBitmap("http://47.101.209.193:8080/picture/birthday"+list.get(i).getImageurl());
                    Recommendedgift gift = list.get(i);
                    gift.setPhoto(mm);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
//            DatabaseManger manger = new DatabaseManger(getContext());
//            doPost();
//            String sql = "select *from classification where id > 22 ";
//            try {
//                list = manger.queryList(sql, null);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            manger.close();
            return list;
        }

        /**
         * UI线程的更新
         */
        @Override
        protected void onPostExecute(List<Recommendedgift> recommendedgifts) {
            super.onPostExecute(recommendedgifts);
            list_data.clear();                     //这里直接list_data=recommendedgifts，是不能刷新界面的
            list_data.addAll(recommendedgifts);         //需要改变list—data的内存地址才能刷新成功
            multiRecyclerAdapter.notifyDataSetChanged();
        }
    }
}
