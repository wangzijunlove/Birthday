package com.example.archermind.birthday.bean;

import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.factory.TypeFactory;



public class ContentBean implements Visitable {
  /**
   * 工厂类返回对应itembean的类型
   *
   */
  @Override public int type(TypeFactory typeFactory) {
    return typeFactory.type(this);
  }
}
