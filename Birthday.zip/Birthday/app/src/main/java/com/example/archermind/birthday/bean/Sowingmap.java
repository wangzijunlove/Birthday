package com.example.archermind.birthday.bean;

import android.content.Context;
import android.graphics.Bitmap;

import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.factory.TypeFactory;

public class Sowingmap implements Visitable {
    private Bitmap bitmap;
    private Context mContext;

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
    public Sowingmap(Bitmap bb,Context context){
        mContext = context;
        bitmap = bb;
    }

    @Override
    public int type(TypeFactory typeFactory) {
        return typeFactory.type(this);
    }
}
