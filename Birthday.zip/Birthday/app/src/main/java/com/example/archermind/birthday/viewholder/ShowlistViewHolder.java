package com.example.archermind.birthday.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowDetailGiftActivity;
import com.example.archermind.birthday.ShowGiftListActivity;
import com.example.archermind.birthday.adapter.DetailShowAdapter;
import com.example.archermind.birthday.adapter.GiftAdapter;
import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.bean.ShowlistBean;
import com.example.archermind.birthday.util.GridDividerItemDecoration;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ShowlistViewHolder extends BaseViewHolder {
    @Bind(R.id.recy_gift_show_list)
    RecyclerView recyclerView;
    @Bind(R.id.img_gift_decribe)
    ImageView imageView_title;
    private GiftAdapter adapter;
    private Context mContext;
    private int flag;
    private static List<Recommendedgift> list = new ArrayList<>();

    @Override
    public void bindViewData(Object data) {
        mContext = ((ShowlistBean) data).getmContext();
        flag = ((ShowlistBean) data).getFLAG_GIFT();
        getFlag();
        Log.e("ShowlistViewHolder", "------------switch photo------");
        list = ((ShowlistBean) data).getList_data();
        adapter = new GiftAdapter(mContext, ((ShowlistBean) data).getList_data());
        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 2);
        recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 20));
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        adapter.setOnRecyclerViewItemListener(new GiftAdapter.OnRecyclerViewItemListener() {
            @Override
            public void onItemClickListener(View view, int position) {
                Log.e("ShowlistViewHolder", "点击了" + position);
                Intent intent = new Intent(mContext, ShowDetailGiftActivity.class);
                intent.putExtra("flag", ShowDetailGiftActivity.TYPE_SHOW_GIFT_SORT);
                intent.putExtra("position",position );
                mContext.startActivity(intent);
            }

            @Override
            public void onItemLongClickListener(View view, int position) {

            }
        });
    }

    public ShowlistViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }

    public static List<Recommendedgift> getData() {
        return list;
    }

    private String getFlag() {
        String flag_show = "";
        if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_EAT) {
            flag_show = "GIFT_EAT";
            imageView_title.setImageResource(R.mipmap.eat);
        } else if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_CREATE) {
            flag_show = "GIFT_CREATE";
            imageView_title.setImageResource(R.mipmap.create);
        } else if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_BABY) {
            flag_show = "GIFT_BABY";
            imageView_title.setImageResource(R.mipmap.babytitle);
        } else if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_DECORATION) {
            flag_show = "GIFT_DECORATION";
            imageView_title.setImageResource(R.mipmap.love);
        } else if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_HEALTH) {
            flag_show = "GIFT_HEALTH";
            imageView_title.setImageResource(R.mipmap.healthtitle);
        } else if (flag == ShowGiftListActivity.TYPE_SHOW_GIFTLIST_HOUSE) {
            flag_show = "GIFT_HOUSE";
            imageView_title.setImageResource(R.mipmap.house);
        }
        return flag_show;
    }
}
