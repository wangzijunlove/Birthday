package com.example.archermind.birthday;

import android.app.Instrumentation;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.BrithDay;

public class EditPersonActivity extends AppCompatActivity {

    private EditText text_name, text_sex, text_phone, text_sinagture;
    private TextView text_save;
    private Button btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_person);
        init();
        btn_back = findViewById(R.id.TitleBackBtn_Editperson);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
    }

    private void init() {
        text_name = findViewById(R.id.edit_name);
        text_phone = findViewById(R.id.edit_elephone);
        text_sex = findViewById(R.id.edit_sex);
        text_sinagture = findViewById(R.id.edit_sinagture);
        text_save = findViewById(R.id.tv_person_save_info);
        text_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("----------------"," save info" );
                String name = text_name.getText().toString();
                String sex = text_sex.getText().toString();
                String phone = text_phone.getText().toString();
                String sinagture = text_sinagture.getText().toString();
                DatabaseManger manger = new DatabaseManger(EditPersonActivity.this);
                ContentValues contentValues = new ContentValues();
                contentValues.put("Username", name);
                contentValues.put("sex", sex);
                contentValues.put("phone", phone);
                contentValues.put("signature", sinagture);
                String[] aa = new String[]{"1"};
                try {
                    manger.updateData("userinfo", contentValues, "id=?",aa);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                startActivity(new Intent(EditPersonActivity.this,ShowPersonActivity.class));
            }
        });
    }


}
