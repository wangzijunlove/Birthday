package com.example.archermind.birthday.util;

import android.content.Context;
import android.widget.Toast;

public class ToastUtil {
    public static void showToast(Context context, String str){
        //Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
        //小米真机调试时,新版MIUI Toast会显示APP名字的问题解决
        Toast toast = Toast.makeText(context, null, Toast.LENGTH_SHORT);
        toast.setText(str);
        toast.show();
    }


        public static Toast mToast;
        public static void showMessage(Context context,String msg) {
            if (mToast == null) {
                mToast = Toast.makeText(context, msg, Toast.LENGTH_SHORT);

            } else {
                mToast.setText(msg);
            }
            mToast.show();
        }
}


