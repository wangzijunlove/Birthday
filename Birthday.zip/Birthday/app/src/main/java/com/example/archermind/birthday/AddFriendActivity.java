package com.example.archermind.birthday;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TimePicker;

import com.example.archermind.birthday.adapter.BrithDayAdapter;
import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.CalendarOpretion;
import com.example.archermind.birthday.util.ListOperation;
import com.example.archermind.birthday.util.Music;
import com.example.archermind.birthday.util.MusicUtils;
import com.example.archermind.birthday.util.ToastUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


public class AddFriendActivity extends AppCompatActivity implements View.OnClickListener {
    private Context context = AddFriendActivity.this;
    private List<String> list = new ArrayList<>();
    private List<Music> musicList=new ArrayList<>();
    private Spinner spinner;
    private Button add;
    final String TAG = "AddFriendActivity";
    private String remind_time, brith_time;
    private AlertDialog.Builder builder;
    private View view;
    private Calendar cal;
    private Dialog dialog;
    private EditText Editbrith, Editremind, Editname, Editphone,EditRemarks;  //输入框
    private ImageView imageView_user;
    private boolean flag = Fragment1.flag_opretion;
    private MediaPlayer mPlayer;
    private DatabaseManger manager;
    private String music_path;
    private BrithDay mbrithDay;
    private int mm;
    private CalendarOpretion calendarOpretion = new CalendarOpretion();
    private Date brith_insert, brith_update;
    private boolean isSpinnerFirst=true;
    private MusicUtils musicUtils = new MusicUtils();
    private ArrayAdapter<String> adapter;
    private Button button_pop;
    private ImageView img;

    private ImageView popBtn;

    private PopupWindow popupWindow;

    private Button pop_img;

    private Button pop_file;

    private Button pop_cancle;
    // private  CameraOPretion cameraOPretion = new CameraOPretion(SeleteActivity.this);
//    //相册请求码
    private static final int ALBUM_REQUEST_CODE =1;
    //相机请求码
    private static final int CAMERA_REQUEST_CODE = 2;
    //剪裁请求码
    private static final int CROP_SMALL_PICTURE = 3;
    //调用照相机返回图片文件
    private File tempFile;
    //最后显示的图片文件
    private  String mFile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);
        manager = new DatabaseManger(context);
        MyThread myThread = new MyThread();
        myThread.start();
        init();
        initPopWindow();
        initView();
        Log.e(TAG, "----onCreate---"+mFile);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.e("ManagerActivity","点击");
                if (isSpinnerFirst) {
                    //第一次初始化spinner时，不显示默认被选择的第一项即可
                    isSpinnerFirst=false;
                }else {
                    isSpinnerFirst = false;
                    Music music = musicList.get(position);
                    Log.e("ManagerActivity","-----"+music.getSong_name());
                    String path = music.getSong_path();
                    music_path = path;
                    if (mPlayer != null) {
                        mPlayer.release();//释放资源
                    }
                    mPlayer = MediaPlayer.create(context, Uri.parse(path));
                    mPlayer.start();
                    for (int i = 0; i <= id; i++)
                        if (id == i)
                            ToastUtil.showToast(context, music.getSong_name());

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.e("ManagerActivity","-----no-------");
            }
        });

    }


    private void initView() {
        img = findViewById(R.id.userImage);
        popBtn = findViewById(R.id.userImage);
        popBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //第一个参数是要将PopupWindow放到的View，第二个参数是位置，第三第四是偏移值
                popupWindow.showAtLocation(popBtn, Gravity.BOTTOM, 0, 0);
            }
        });
    }

    public void initPopWindow() {
        View popView = getLayoutInflater().inflate(R.layout.popwindow, null);

        popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        pop_img = (Button) popView.findViewById(R.id.btn_camera_pop_camera);
        pop_file = (Button) popView.findViewById(R.id.btn_camera_pop_album);
        pop_cancle = (Button) popView.findViewById(R.id.btn_camera_pop_cancel);
        pop_img.setOnClickListener(this);
        pop_file.setOnClickListener(this);
        pop_cancle.setOnClickListener(this);
    }



    @SuppressLint("HandlerLeak")
    public Handler mhandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:

                    ArrayList blueRet = msg.getData().getParcelableArrayList("CLASSIC");
                    list = blueRet;
                    adapter= new ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, list);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapter);
                    adapter.notifyDataSetChanged();  //发现新的设备更新UI
                    Log.e("mHandle","            "+blueRet.get(0)+list.size());
                    // mhandler.removeMessages(1);
                    //Log.d("listviewclassic", "ID" + user.getId() + "姓名" + user.getCurrPhoto() + "地址  " + user.getPhotoPath());
                    break;

            }

        }
    };

    /**
     * 初始化
     * 对布局上的控件进行初始化操作
     * 同时在这里接受intent传递过来的数据
     */

    @SuppressLint("ClickableViewAccessibility")
    private void init() {

        Editbrith = findViewById(R.id.brithdayDate);
        Editbrith.setOnClickListener(this);  //设置监听
        Editremind = findViewById(R.id.remindDate);
        Editremind.setOnClickListener(this);
        add = findViewById(R.id.add);
        add.setOnClickListener(this);
        Editname = findViewById(R.id.userName);
        Editphone = findViewById(R.id.phoneNumber);
        EditRemarks = findViewById(R.id.edit_birthday_remark);
        spinner = findViewById(R.id.spinner);
        imageView_user = findViewById(R.id.userImage);
//        musicList = musicUtils.getMusic(context);
//        for (int i = 0; i < musicList.size(); i++) {
//            list.add(musicList.get(i).getSong_name());
//        }
        //flag是主界面的flag_opretion,为true是代表是修改功能，此时接受intent的数据
        //找到这个id的数据的对应的list中的内容填充到控件上
        if (flag == true) {
            Intent intent = getIntent();//获取传来的intent对象
            Bundle bundle = intent.getExtras();
            mm = bundle.getInt("id");
            Log.e(TAG, "data" + mm);
            mbrithDay = Fragment1.list_brith.get(mm);
            add.setText(R.string.update);
            Editname.setText(mbrithDay.getName());
            Editphone.setText(mbrithDay.getTelephone());
            Editbrith.setText(mbrithDay.getBrithday());
            Editremind.setText(mbrithDay.getRemind());
            EditRemarks.setText(mbrithDay.getRemarks());
            if(!Fragment1.list_brith.get(mm).getPhoto().equals("kong")) {
                BrithDayAdapter brithDayAdapter = new BrithDayAdapter();
                try {
                    imageView_user.setImageBitmap(brithDayAdapter.getRoundBitmap(brithDayAdapter.decodeBitmap(Fragment1.list_brith.get(mm).getPhoto()),14 ));
                } catch (Exception e) {
                    e.printStackTrace();
                    imageView_user.setImageResource(R.drawable.avatar);
                }
            }else {
                imageView_user.setImageResource(R.drawable.avatar);
            }
        } else {
            add.setText(R.string.add);
            imageView_user.setImageResource(R.drawable.avatar);
        }


        Editbrith.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // TODO Auto-generated method stub
                    //创建弹出对话框对象
                    builder = new AlertDialog.Builder(context);
                    //对话框布局
                    view = View.inflate(context, R.layout.dialog, null);      //日期控件初始化
                    final DatePicker brithdayDatePicker = view.findViewById(R.id.date_picker);
                    //时间控件初始化
                    final TimePicker brithtimePicker = view.findViewById(R.id.time_picker);
                    builder.setView(view);

                    cal = Calendar.getInstance();
                    cal.setTimeInMillis(System.currentTimeMillis());
                    brithdayDatePicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
                    //24小时制
                    brithtimePicker.setIs24HourView(true);
                    final int inType_brithday = Editbrith.getInputType();
                    Editbrith.setInputType(InputType.TYPE_NULL);
                    Editbrith.setInputType(inType_brithday);
                    Editbrith.setSelection(Editbrith.getText().length());
                    builder.setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {

                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            brith_time = brithdayDatePicker.getYear() + "-" + (brithdayDatePicker.getMonth() + 1) + "-"
                                    + brithdayDatePicker.getDayOfMonth();
                            Editbrith.setText(brith_time);

                            dialog.cancel();
                        }
                    });

                    builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    dialog = builder.create();
                    Window w=dialog.getWindow();
                    w.setWindowAnimations(R.style.dialogWindowAnim);
                    dialog.show();
                }
                return true;
            }
        });

        Editremind.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // TODO Auto-generated method stub
                    //创建弹出对话框对象
                    builder = new AlertDialog.Builder(context);
                    //对话框布局
                    view = View.inflate(context, R.layout.dialog, null);      //日期控件初始化
                    final DatePicker remindPicker = view.findViewById(R.id.date_picker);
                    //时间控件初始化
                    final TimePicker remindtimePicker = view.findViewById(R.id.time_picker);
                    builder.setView(view);
                    cal = Calendar.getInstance();
                    cal.setTimeInMillis(System.currentTimeMillis());
                    remindPicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
                    //24小时制
                    remindtimePicker.setIs24HourView(true);

                    final int inType_remind = Editremind.getInputType();
                    Editremind.setInputType(InputType.TYPE_NULL);
                    Editremind.setInputType(inType_remind);
                    Editremind.setSelection(Editremind.getText().length());
                    builder.setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {

                        @RequiresApi(api = Build.VERSION_CODES.M)
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String ss=null;
                            if(remindtimePicker.getMinute()<10){
                                ss="0"+remindtimePicker.getMinute();
                            }else {
                                ss=""+remindtimePicker.getMinute();
                            }
                            remind_time = remindPicker.getYear() + "-" + (remindPicker.getMonth() + 1) + "-" + remindPicker.getDayOfMonth() + "   " + remindtimePicker.getHour() + " : " + ss;
                            Editremind.setText(remind_time);

                            dialog.cancel();
                        }
                    });

                    builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    dialog = builder.create();
                    Window w=dialog.getWindow();
                    w.setWindowAnimations(R.style.dialogWindowAnim);
                    dialog.show();
                }
                return true;


            }
        });
    }


    /**
     * 点击事件
     *
     * @param v
     */
    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_camera_pop_camera:
                //关闭popupWindow
                popupWindow.dismiss();
                getPicFromCamera();//拍照

                break;
            case R.id.btn_camera_pop_album:
                popupWindow.dismiss();
                getPicFromAlbm();//从系统相册选择

                break;
            case R.id.btn_camera_pop_cancel:
                popupWindow.dismiss();
                break;
            case R.id.add:
                /**
                 * 对按钮进行监听
                 * flag为false，进行增加功能，获取到文本框的数据，判断数据为空时不进行增加操作
                 */
                if (flag == false) {
                    String name = Editname.getText().toString();
                    String phone = Editphone.getText().toString();
                    String remark = EditRemarks.getText().toString();
                    if (name.equals("") || phone.equals("") || Editbrith.getText().toString().equals("") || Editremind.getText().toString().equals("")) {
                        ToastUtil.showToast(context, "data is empty");
                        break;
                    } else {
                        String music = music_path;
                        String photo;
                        if(mFile!=null) {
                            photo = mFile;
                        }else {
                            photo="kong";
                        }
                        Log.e(TAG,"  "+mFile);
//                        String.valueOf(Uri.fromFile(tempFile));
                        BrithDay brithday = new BrithDay(name, phone, brith_time, remind_time, music, photo,remark);
                        manager.insert(brithday);
                        Fragment1.list_brith.add(brithday);
                        Log.d(TAG, "onClick: " + brith_time);
                        Log.d(TAG, "onClick: " + remind_time);
                        Intent intent = new Intent(AddFriendActivity.this, BottomActivity.class);
                        intent.putExtra("flag", 1);
                        startActivity(intent);
                        ToastUtil.showMessage(AddFriendActivity.this, this.getString(R.string.add_success));
                        manager.close();

                        /**
                         * 在增加的事件里将提醒事件通过CalendarOpretion，将提醒时间添加到系统日历中
                         * 提醒功能由系统的日历进行维护
                         */
                        String remindtime = remind_time;
                        DateFormat format = new SimpleDateFormat("yyyy-MM-dd   HH : mm");
                        try {
                            brith_insert = format.parse(remindtime);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        long starttime = brith_insert.getTime();
                        long endtime = brith_insert.getTime() + 1000 * 60;
                        calendarOpretion.insertCalendarEvent(AddFriendActivity.this, name + "生日提醒", name + "生日到了" + "请送上你的祝福", starttime, endtime);
                        break;
                    }
                } else {
                    /**
                     * 修改功能
                     * 将文本框中的数据提取出来，将数据库和list中的这条数据修改
                     *
                     */
                    String photo=null;
                    String name = Editname.getText().toString();
                    String phone = Editphone.getText().toString();
                    String brith = Editbrith.getText().toString();
                    String remind = Editremind.getText().toString();
                    String music = music_path;
                    String remark = EditRemarks.getText().toString();
                    Log.e(TAG,"  "+mFile);
                    if(mFile!=null) {
                        photo= mFile;
                    }else {
                        photo=Fragment1.list_brith.get(mm).getPhoto();
                    }
                    if (name == null || brith == null || null == remind) {
                        ToastUtil.showMessage(AddFriendActivity.this, "不能为空");
                    } else {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("name", name);
                        contentValues.put("music", music);
                        contentValues.put("remind", remind);
                        contentValues.put("brith", brith);
                        contentValues.put("phone", phone);
                        contentValues.put("photo", photo);
                        contentValues.put("remarks", remark);
                        BrithDay update_brithDay = new BrithDay(name, phone, brith, remind, music, photo,remark);
                        String[] aa = new String[]{ Fragment1.list_brith.get(mm).getName()};
                        try {
                            manager.updateData("brithday", contentValues, "name=?",aa);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Fragment1.list_brith.set(mm, update_brithDay);
                        Intent intent = new Intent(AddFriendActivity.this, BottomActivity.class);
                        intent.putExtra("flag", 1);
                        startActivity(intent);
                        manager.close();
                        ToastUtil.showMessage(AddFriendActivity.this, this.getString(R.string.update_success));
                        /**
                         * 通过标题对这条数据对应的日历中的数据进行修改
                         */
                        String remindtime = remind;
                        DateFormat format = new SimpleDateFormat("yyyy-MM-dd   HH : mm");
                        try {
                            brith_update = format.parse(remindtime);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        long starttime = brith_update.getTime();
                        long endtime = brith_update.getTime() + 1000 * 60;
                        String title = name + "生日提醒";
                        String description = name + "生日到了" + "请送上你的祝福";
                        ContentValues eventValues = new ContentValues();
                        eventValues.put(CalendarContract.Events.DTSTART, starttime);
                        eventValues.put(CalendarContract.Events.DTEND, endtime);
                        eventValues.put(CalendarContract.Events.TITLE, title);
                        eventValues.put(CalendarContract.Events.DESCRIPTION, description);
                        eventValues.put(CalendarContract.Events.CALENDAR_ID, 1);
                        eventValues.put(CalendarContract.Events.EVENT_LOCATION, "生日提醒");
                        eventValues.put(CalendarContract.Events.HAS_ALARM, true);
                        eventValues.put(CalendarContract.Events.RRULE, "FREQ=YEARLY;WKST=SU");
                        TimeZone tz = TimeZone.getDefault(); // 获取默认时区
                        eventValues.put(CalendarContract.Events.EVENT_TIMEZONE, tz.getID());
                        CalendarOpretion.updateCalendarEvent(this, eventValues, title);

                    }
                }
                break;
            default:
                break;
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "----onDestroy---");

    }

    @Override
    protected void onStop() {
        Log.e(TAG, "----onStop---");
        super.onStop();
        if (mPlayer != null) {
            mPlayer.stop();
        }
        if(list.size()>0){
            list.clear();
        }
    }

    @Override
    protected void onPause() {
        Log.e(TAG, "----onPause---");
        super.onPause();
    }

    class MyThread extends Thread{
        @Override
        public void run() {
            super.run();
            ArrayList<String> list_data = new ArrayList<>();
            list_data= getMusic();
            Message msg = new Message();
            msg.what = 1;
            Bundle b = new Bundle();
            b.putStringArrayList("CLASSIC",  list_data);
            msg.setData(b);
            // Handler handler=MainActivity.handlerOPeration.getHandler();
            mhandler.sendMessage(msg);
            Log.e("ManagerActivity","---------------------run--------------"+list_data.size()+musicList.size());
        }
        public  ArrayList<String> getMusic() {
            ArrayList<String> list = new ArrayList<>();
            RingtoneManager manager = new RingtoneManager(context);
            manager.setType(RingtoneManager.TYPE_ALARM);
            Cursor cursor = manager.getCursor();
            Log.e("MusicUtils", "thread run");
            if (cursor.moveToFirst()) {
                while (cursor.moveToNext()) {
                    String ringName = manager.getRingtone(cursor.getPosition()).getTitle(context);
                    String ringPath = manager.getRingtoneUri(cursor.getPosition()).toString();
                    Music music = new Music(ringName,ringPath);
                    if(new ListOperation().RemoveRepeat(musicList, music)){
                        list.add(music.getSong_name());
                        musicList.add(music);
                    }
                    Log.d("ManagerActivity"," -------------"+ringName+ringPath);

                }
            }
            return list;
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode) {
            case CAMERA_REQUEST_CODE:   //调用相机后返回
                if (resultCode == RESULT_OK) {
                    //用相机返回的照片去调用剪裁也需要对Uri进行处理
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        Uri contentUri = FileProvider.getUriForFile(this, "com.example.archermind.birthday.provider", tempFile);
                        startPhotoZoom(contentUri);//开始对图片进行裁剪处理
                    } else {
                        startPhotoZoom(Uri.fromFile(tempFile));//开始对图片进行裁剪处理
                    }
                }
                break;
            case ALBUM_REQUEST_CODE:    //调用相册后返回
                if (resultCode == RESULT_OK) {
                    Uri uri = intent.getData();
                    startPhotoZoom(uri); // 开始对图片进行裁剪处理
                }
                break;
            case CROP_SMALL_PICTURE:  //调用剪裁后返回
                if (intent != null) {
                    // 让刚才选择裁剪得到的图片显示在界面上
                    Bitmap photo = BitmapFactory.decodeFile(mFile);
                    img.setImageBitmap(new BrithDayAdapter().getRoundBitmap(photo, 14));
                } else {
                    Log.e("data","data为空");
                }
                break;
        }

    }
    public String saveImage(String name, Bitmap bmp) {
        File appDir = new File(Environment.getExternalStorageDirectory().getPath());
        if (!appDir.exists()) {
            appDir.mkdir();
        }
        String fileName = name + ".png";
        File file = new File(appDir, fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 裁剪图片方法实现
     *
     * @param uri
     */
    protected void startPhotoZoom(Uri uri) {

        if (uri == null) {
            Log.i("tag", "The uri is not exist.");
        }
//        tempUri = uri;
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.setDataAndType(uri, "image/*");
        // 设置裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("return-data", false);
        File out = new File(getPath());
        if (!out.getParentFile().exists()) {
            out.getParentFile().mkdirs();
        }
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(out));
        startActivityForResult(intent, CROP_SMALL_PICTURE);
    }
    //裁剪后的地址
    public  String getPath() {
        //resize image to thumb
        if (mFile == null) {
            Calendar.getInstance();
            String Date= String.valueOf(Calendar.getInstance().getTime().getTime());
            mFile = Environment.getExternalStorageDirectory() + "/" +"wode/"+ Date+".png";
            Log.e("-----------------------", ""+mFile);
        }
        return mFile;
    }
    /**
     * 从相机获取图片
     */
    private void getPicFromCamera() {


        //用于保存调用相机拍照后所生成的文件
        tempFile = new File(Environment.getExternalStorageDirectory().getPath(), System.currentTimeMillis() + ".png");
        //跳转到调用系统相机
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //判断版本
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {   //如果在Android7.0以上,使用FileProvider获取Uri
            intent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Uri contentUri = FileProvider.getUriForFile(this, "com.example.archermind.birthday.provider", tempFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, contentUri);
            Log.e("getPicFromCamera", contentUri.toString());
        } else {    //否则使用Uri.fromFile(file)方法获取Uri
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(tempFile));
        }
        startActivityForResult(intent, CAMERA_REQUEST_CODE);
    }

    /**
     * 从相册获取图片
     */
    private void getPicFromAlbm() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, ALBUM_REQUEST_CODE);
    }

}
