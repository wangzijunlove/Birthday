package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.archermind.birthday.R;
import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.SlidingButtonView;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.List;

public class SlideAdapter extends RecyclerView.Adapter<SlideAdapter.MyViewHolder>  implements SlidingButtonView.IonSlidingButtonListener {
    private List<BrithDay> list_data = new ArrayList<>();
    private SlidingButtonView mMenu = null;
    SlidingButtonView.IonSlidingButtonListener mIonSlidingButtonListener;
    private IonSlidingViewClickListener mIDeleteBtnClickListener;
    private Context mContext;
    public SlideAdapter(List<BrithDay> list, Context context){
        list_data = list;
        mContext = context;
        mIDeleteBtnClickListener = (IonSlidingViewClickListener) context;
    }
    @NonNull
    @Override
    public SlideAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        final View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.spsn_item, viewGroup, false);
        SlideAdapter.MyViewHolder holder = new SlideAdapter.MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final SlideAdapter.MyViewHolder myViewHolder, int i) {
        BrithDay birthday = list_data.get(i);
        myViewHolder.textView_name.setText(birthday.getName());
        myViewHolder.textView_date.setText(birthday.getBrithday());
        myViewHolder.imageView_title.setImageBitmap(Utils.decodeBitmap(birthday.getPhoto()));
        myViewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {//删除按钮的监听
            @Override
            public void onClick(View v) {
                int n = myViewHolder.getLayoutPosition();
                removeData(n);
            }
        });
        myViewHolder.layout_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = myViewHolder.getLayoutPosition();
                mIDeleteBtnClickListener.onDeleteCilck(v, n);
            }
        });
        myViewHolder.layout_content.getLayoutParams().width = Utils.getScreenWidth(mContext);
    }

    @Override
    public int getItemCount() {
        return list_data.size();
    }
   public  class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_name,tv_show,tv_delete;
        private ViewGroup layout_content;
        private ImageView imageView_title;
        private TextView textView_name,textView_date,textView_day;
       public MyViewHolder(@NonNull View itemView) {
           super(itemView);
           imageView_title = itemView.findViewById(R.id.img_birth_photo);
           textView_name = itemView.findViewById(R.id.tv_birth_name);
           textView_date = itemView.findViewById(R.id.tv_birth_date);
           textView_day = itemView.findViewById(R.id.tv_birth_day);
           tv_delete = itemView.findViewById(R.id.tv_delete);
           layout_content = (ViewGroup) itemView.findViewById(R.id.layout_content);
           ((SlidingButtonView) itemView).setSlidingButtonListener(SlideAdapter.this);
       }
   }

    /**
     * 删除菜单打开信息接收
     */
    @Override
    public void onMenuIsOpen(View view) {
        mMenu = (SlidingButtonView) view;
    }


    /**
     * 滑动或者点击了Item监听
     * @param slidingButtonView
     */
    @Override
    public void onDownOrMove(SlidingButtonView slidingButtonView) {
        if(menuIsOpen()){
            if(mMenu != slidingButtonView){
                closeMenu();
            }
        }

    }

    /**
     * 关闭菜单
     */
    public void closeMenu() {
        mMenu.closeMenu();
        mMenu = null;

    }
    /**
     * 判断是否有菜单打开
     */
    public Boolean menuIsOpen() {
        if(mMenu != null){
            Log.i("asd","mMenu不为null");
            return true;
        }
        Log.i("asd","mMenu为null");
        return false;
    }
    public interface IonSlidingViewClickListener {
        void onDeleteCilck(View view, int position);
    }

    public void removeData(int position){
        list_data.remove(position);
        notifyItemRemoved(position);

    }

}
