package com.example.archermind.birthday.decorate;

import com.example.archermind.birthday.factory.TypeFactory;


public interface Visitable {
    int type(TypeFactory typeFactory);
}
