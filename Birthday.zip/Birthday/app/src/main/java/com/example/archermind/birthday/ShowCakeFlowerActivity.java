package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.adapter.ShowAdapter;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Cakeflower;
import com.example.archermind.birthday.util.GridDividerItemDecoration;
import com.example.archermind.birthday.util.Showgift;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ShowCakeFlowerActivity extends AppCompatActivity {
    public static final int TYPE_SHOW_GIFT_CAKE = 0x07;
    public static final int TYPE_SHOW_GIFT_FLOWER = 0x08;
    private RecyclerView recyclerView;
    private String TAG = "ShowCakeFlowerActivity";
    private List<Cakeflower> list_data = new ArrayList<>();
    DatabaseManger manger;
    private ImageView imageView_back;
    private TextView  textView_search;
    Intent intentflag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_cake_flower);
        init();
//        imageView_back = findViewById(R.id.tv_city1);
//        imageView_back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                new Thread() {
//                    public void run() {
//                        try {
//                            Instrumentation inst = new Instrumentation();
//                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
//                        } catch (Exception e) {
//                        }
//                    }
//                }.start();
//            }
//        });
//        textView_search = findViewById(R.id.tv_search_main1);
//        textView_search.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(ShowCakeFlowerActivity.this,SearchActivity.class));
//            }
//        });
    }

    /**
     * 初始化判断显示的界面是蛋糕还是鲜花
     */
    private void init() {
        final Intent intent = getIntent();
        String sql = null;
        int msg = intent.getIntExtra("flag", 0);
        if (msg == TYPE_SHOW_GIFT_CAKE) {
            intentflag = new Intent(ShowCakeFlowerActivity.this,ShowCakeActivity.class);
            manger = new DatabaseManger(ShowCakeFlowerActivity.this);
            sql = "select *from cakeflower where kind = 'cake' ";
            try {
                list_data = manger.querycakeflowerList(sql, null);
                Log.e(TAG, "commodity查询成功" + list_data.size());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "commodity查询失败");
            }
            manger.close();
        } else if (msg == TYPE_SHOW_GIFT_FLOWER) {
            intentflag = new Intent(ShowCakeFlowerActivity.this,ShowFlowerActivity.class);
            manger = new DatabaseManger(ShowCakeFlowerActivity.this);
            sql = "select *from cakeflower where kind = 'flower' ";
            try {
                list_data = manger.querycakeflowerList(sql, null);
                Log.e(TAG, "commodity查询成功" + list_data.size());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "commodity查询失败");
            }
            manger.close();
        }
        recyclerView = findViewById(R.id.recy_home_showcake);
        ShowAdapter adapter = new ShowAdapter(ShowCakeFlowerActivity.this, list_data);
        GridLayoutManager layoutManager = new GridLayoutManager(ShowCakeFlowerActivity.this, 2);
        recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 20));
        recyclerView.setLayoutManager(layoutManager);
//            recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 1));
        recyclerView.setAdapter(adapter);


        adapter.setOnRecyclerViewItemListener(new ShowAdapter.OnRecyclerViewItemListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onItemClickListener(View view, int position) {
                Log.e("-----------------------------","start jump");
                intentflag.putExtra("name",list_data.get(position).getName() );
                intentflag.putExtra("price",list_data.get(position).getPrice() );
                intentflag.putExtra("photo",list_data.get(position).getPhotourl() );
                startActivity(intentflag);
                Log.e("-----------------------------",""+list_data.get(position).getName()+list_data.get(position).getPrice());
            }

            @Override
            public void onItemLongClickListener(View view, int position) {

            }
        });
    }



}
