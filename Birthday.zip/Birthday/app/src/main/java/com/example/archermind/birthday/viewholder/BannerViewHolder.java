package com.example.archermind.birthday.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowCakeFlowerActivity;
import com.example.archermind.birthday.ShowDetailGiftActivity;
import com.example.archermind.birthday.adapter.DetailShowAdapter;
import com.example.archermind.birthday.adapter.SlideAdapter;
import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.fragment.Fragment2;
import com.example.archermind.birthday.fragment.Fragment3;
import com.example.archermind.birthday.util.Recommendedgift;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.os.Handler;
import android.os.Message;
import butterknife.Bind;
import butterknife.ButterKnife;


public class BannerViewHolder extends BaseViewHolder {
  private static DetailShowAdapter detailShowAdapter;
  private Context mContext;
  @Bind(R.id.recy_gift_detailshow)
  RecyclerView recyclerView;
  public BannerViewHolder(View itemView) {
    super(itemView);
    ButterKnife.bind(this, itemView);
  }

  private static Recommendedgift recommendedgift;

  public static  Recommendedgift getGift(){
    return recommendedgift;
  }

  @Override public void bindViewData(final Object data) {
    mContext = ((BannerBean)data).getmContext();
    LinearLayoutManager manager = new LinearLayoutManager(((BannerBean)data).getmContext());
    detailShowAdapter = new DetailShowAdapter(((BannerBean)data).getmContext(),((BannerBean)data).getList_data());
    recyclerView.setLayoutManager(manager);
    recyclerView.addItemDecoration(new DividerItemDecoration(((BannerBean)data).getmContext(),1));
    recyclerView.setAdapter(detailShowAdapter);
    detailShowAdapter.setOnRecyclerViewItemListener(new DetailShowAdapter.OnRecyclerViewItemListener() {
      @Override
      public void onItemClickListener(View view, int position) {
        Log.e("点击了礼物","OnTouch"+position);
        recommendedgift = ((BannerBean) data).getList_data().get(position);
        Intent intent = new Intent(mContext,ShowDetailGiftActivity.class);
        intent.putExtra("flag",ShowDetailGiftActivity.TYPE_SHOW_GIFT_RECOMMEND);
        mContext.startActivity(intent);
      }

      @Override
      public void onItemLongClickListener(View view, int position) {

      }
    });

  }

  public static DetailShowAdapter getAdapter(){
    return detailShowAdapter;
  }

}
