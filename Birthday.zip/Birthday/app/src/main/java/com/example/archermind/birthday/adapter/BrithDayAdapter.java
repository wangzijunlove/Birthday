package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.SlidingButtonView;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BrithDayAdapter extends RecyclerView.Adapter<BrithDayAdapter.MyviewHolder> implements Filterable ,SlidingButtonView.IonSlidingButtonListener  {
    private List<BrithDay> list = new ArrayList<>();
    private Context mContext;
    private LayoutInflater mInflater;
    private MyFilter filter = null;// 创建MyFilter对象
    private Fragment1.FilterListener listener = null;// 接口对象
    SlidingButtonView.IonSlidingButtonListener mIonSlidingButtonListener;
    private SlidingButtonView mMenu = null;
    private IonSlidingViewClickListener mIDeleteBtnClickListener;
    public BrithDayAdapter(){

    }
    /**
     * 构造方法
     *
     * @param list
     * @param context
     * @param listener 监听文本框内容
     */

    public BrithDayAdapter(List<BrithDay> list, Context context , Fragment1.FilterListener listener) {
        this.list = list;
        this.mContext = context;
        this.listener=listener;
        mIDeleteBtnClickListener = (IonSlidingViewClickListener) context;
    }

    private void itemOnClick(final BrithDayAdapter.MyviewHolder holder) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getLayoutPosition();
                mIDeleteBtnClickListener.onItemClickListener(holder.itemView, pos);
            }
        });
    }

    private void itemOnLongClick(final BrithDayAdapter.MyviewHolder holder) {
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int pos = holder.getLayoutPosition();
                mIDeleteBtnClickListener.onItemLongClickListener(holder.itemView, pos);

                //返回true是为了防止触发onClick事件
                return true;
            }
        });
    }

    public List<BrithDay> getList() {
        return list;
    }

    @NonNull
    @Override
    public BrithDayAdapter.MyviewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        final View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.spsn_item, viewGroup, false);
        BrithDayAdapter.MyviewHolder holder = new BrithDayAdapter.MyviewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final BrithDayAdapter.MyviewHolder viewHolder, int i) {
        BrithDay birthday = list.get(i);
        //通过时间算法的生日倒计时时间
        int Timeflag = birthday.getTime();
       if(Timeflag == 0){
            viewHolder.textView_day.setText("今天生日");   //剩余零天则显示今天生日
        }else {
            viewHolder.textView_day.setText(String.valueOf(Timeflag)+"天");  //显示还有多少天生日
        }
        viewHolder.textView_name.setText(birthday.getName());
        viewHolder.textView_date.setText(birthday.getBrithday());
        /**
          加载联系人头像，如果没有找到头像时，显示默认的头像
          找到头像时，对图片进行剪裁显示圆形头像
         **/
        if(!birthday.getPhoto().equals("kong")) {
            try {
                viewHolder.imageView_title.setImageBitmap(getCroppedBitmap(decodeBitmap(birthday.getPhoto()),100));
            } catch (Exception e) {
                e.printStackTrace();
                viewHolder.imageView_title.setImageResource(R.drawable.avatar);
            }
        }else {
            viewHolder.imageView_title.setImageResource(R.drawable.avatar);
        }
        viewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {//删除按钮的监听
            @Override
            public void onClick(View v) {
                int n = viewHolder.getLayoutPosition();
                mIDeleteBtnClickListener.onDeleteBtnCilck(v, n);
            }
        });
        viewHolder.layout_content.setOnClickListener(new View.OnClickListener() {  //单击Item事件
            @Override
            public void onClick(View v) {
                int n = viewHolder.getLayoutPosition();
                mIDeleteBtnClickListener.onBtnClick(v, n);
            }
        });
        viewHolder.textView_upadte.setOnClickListener(new View.OnClickListener() {//更新的按钮监听
            @Override
            public void onClick(View v) {
                int n = viewHolder.getLayoutPosition();
                mIDeleteBtnClickListener.onUpdateBtnClick(v, n);
            }
        });
        viewHolder.layout_content.getLayoutParams().width = Utils.getScreenWidth(mContext);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class MyviewHolder extends RecyclerView.ViewHolder {
        private TextView tv_delete,textView_upadte;
        private ViewGroup layout_content;
        private ImageView imageView_title;
        private TextView textView_name,textView_date,textView_day;
        public MyviewHolder(View itemView) {
            super(itemView);
            imageView_title = itemView.findViewById(R.id.img_birth_photo);
            textView_name = itemView.findViewById(R.id.tv_birth_name);
            textView_date = itemView.findViewById(R.id.tv_birth_date);
            textView_day = itemView.findViewById(R.id.tv_birth_day);
            tv_delete = itemView.findViewById(R.id.tv_delete);
            textView_upadte = itemView.findViewById(R.id.tv_update);
            layout_content = (ViewGroup) itemView.findViewById(R.id.layout_content);
            ((SlidingButtonView) itemView).setSlidingButtonListener(BrithDayAdapter.this);
        }
    }

//
//    public interface OnRecyclerViewItemListener {
//        public void onItemClickListener(View view, int position);
//
//        public void onItemLongClickListener(View view, int position);
//    }
//
//    private OnRecyclerViewItemListener mOnRecyclerViewItemListener;
//
//    public void setOnRecyclerViewItemListener(OnRecyclerViewItemListener listener) {
//        mOnRecyclerViewItemListener = listener;
//    }


    public Filter getFilter() {
        // 如果MyFilter对象为空，那么重写创建一个
        if (filter == null) {
            filter = new MyFilter(list);
        }
        return filter;
    }


    class MyFilter extends Filter {

        // 创建集合保存原始数据
        private List<BrithDay> original = new ArrayList<>();

        public MyFilter(List<BrithDay> list) {
            this.original = list;
        }


        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if(TextUtils.isEmpty(constraint)){
                results.values = original;
                results.count = original.size();
            }else {
                // 创建集合保存过滤后的数据
                List<BrithDay> mList = new ArrayList<>();
                // 遍历原始数据集合，根据搜索的规则过滤数据
                for(BrithDay s: original){
                    // 这里就是过滤规则的具体实现【规则有很多，大家可以自己决定怎么实现】
                    if(s.getName().toLowerCase().contains(constraint.toString().trim().toLowerCase())){
                        // 规则匹配的话就往集合中添加该数据
                        mList.add(s);
                    }
                }
                results.values = mList;
                results.count = mList.size();
            }

            // 返回FilterResults对象
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            list = (List<BrithDay>) results.values;
            // 如果接口对象不为空，那么调用接口中的方法获取过滤后的数据，具体的实现在new这个接口的时候重写的方法里执行
            if(listener != null){
                listener.getFilterData(list);
            }
            // 刷新数据源显示
            notifyDataSetChanged();

        }
    }

    public void setSlidingButtonListener(SlidingButtonView.IonSlidingButtonListener listener){
        mIonSlidingButtonListener = listener;
    }



    public void removeData(int position){
        list.remove(position);
        notifyItemRemoved(position);

    }

    /**
     * 删除菜单打开信息接收
     */
    @Override
    public void onMenuIsOpen(View view) {
        mMenu = (SlidingButtonView) view;
    }

    /**
     * 滑动或者点击了Item监听
     * @param slidingButtonView
     */
    @Override
    public void onDownOrMove(SlidingButtonView slidingButtonView) {
        if(menuIsOpen()){
            if(mMenu != slidingButtonView){
                closeMenu();
            }
        }

    }

//    @Override
//    public void onItemClickListener(View view, int position) {
//        Log.e("BrithDay","single click"+position);
//    }

    /**
     * 关闭菜单
     */
    public void closeMenu() {
        if (menuIsOpen() ) {
            mMenu.closeMenu();
            mMenu = null;
        }
    }
    /**
     * 判断是否有菜单打开
     */
    public Boolean menuIsOpen() {
        if(mMenu != null){
            Log.i("asd","mMenu不为null");
            return true;
        }
        Log.i("asd","mMenu为null");
        return false;
    }



    public interface IonSlidingViewClickListener {
        void onDeleteBtnCilck(View view, int position);
        void onBtnClick(View view, int position);
        void onUpdateBtnClick(View view,int position);
        void onItemClickListener(View view, int position);
        void onItemLongClickListener(View view, int position);
    }


   //通过图片的路径进行剪切返回Bitmap类型的图片
    public Bitmap decodeBitmap(String path) {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(path, op); //获取尺寸信息
        //获取比例大小
        //int height = op.outHeight * 100 / op.outWidth;
        op.inSampleSize = op.outHeight / 200;
        op.inJustDecodeBounds = false;
        bmp = BitmapFactory.decodeFile(path, null);
        return bmp;
    }
    //剪切椭圆的类型图片
    public Bitmap getRoundBitmap(Bitmap bitmap, int roundPx) {
        Paint paint = new Paint();
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;

        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        int x = bitmap.getWidth();

        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;


    }
    //剪切圆形的图片
    public static Bitmap getCroppedBitmap(Bitmap bmp, int radius) {
        Bitmap sbmp;
        if(bmp.getWidth() != radius || bmp.getHeight() != radius)
            sbmp = Bitmap.createScaledBitmap(bmp, radius, radius, false);
        else
            sbmp = bmp;

        Bitmap output = Bitmap.createBitmap(sbmp.getWidth(), sbmp.getHeight(), Bitmap.Config.ARGB_8888);
        final Rect rect = new Rect(0, 0, sbmp.getWidth(), sbmp.getHeight());

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);
        paint.setColor(Color.parseColor("#BAB399"));

        Canvas c = new Canvas(output);
        c.drawARGB(0, 0, 0, 0);
        c.drawCircle(sbmp.getWidth() / 2+0.7f, sbmp.getHeight() / 2+0.7f, sbmp.getWidth() / 2+0.1f, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        c.drawBitmap(sbmp, rect, rect, paint);

        return output;
    }
}
