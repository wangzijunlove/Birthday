package com.example.archermind.birthday.util;

public class Music {
    private String song_name;
    private String song_path;

    public String getSong_name() {
        return song_name;
    }

    public void setSong_name(String song_name) {
        this.song_name = song_name;
    }

    public String getSong_path() {
        return song_path;
    }

    public void setSong_path(String song_path) {
        this.song_path = song_path;
    }

    public Music() { }
    public Music(String song_name, String song_path) {
        this.song_name = song_name;
        this.song_path = song_path;
    }
}
