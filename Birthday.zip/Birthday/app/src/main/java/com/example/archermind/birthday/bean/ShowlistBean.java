package com.example.archermind.birthday.bean;

import android.content.Context;

import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.factory.TypeFactory;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Showgift;

import java.util.ArrayList;
import java.util.List;

public class ShowlistBean implements Visitable {
    private Context mContext;
    List<Recommendedgift> list_data = new ArrayList();
    private int FLAG_GIFT;

    public int getFLAG_GIFT() {
        return FLAG_GIFT;
    }

    public void setFLAG_GIFT(int FLAG_GIFT) {
        this.FLAG_GIFT = FLAG_GIFT;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public List<Recommendedgift> getList_data() {
        return list_data;
    }

    public void setList_data(List<Recommendedgift> list_data) {
        this.list_data = list_data;
    }

    public ShowlistBean(Context context,List<Recommendedgift> list,int flag){
        mContext = context;
        list_data = list;
        FLAG_GIFT = flag;
    }

    @Override
    public int type(TypeFactory typeFactory) {
        return typeFactory.type(this);
    }
}
