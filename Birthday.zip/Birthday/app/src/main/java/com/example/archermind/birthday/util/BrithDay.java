package com.example.archermind.birthday.util;

public class BrithDay {
    private String photo;
    private String telephone;
    private String name;
    private String brithday;
    private String music;
    private String remind;
    private String remarks;
    private int Time;

    public int getTime() {
        return Time;
    }

    public void setTime(int time) {
        Time = time;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getMusic() {
        return music;
    }

    public void setMusic(String music) {
        this.music = music;
    }

    public String getRemind() {
        return remind;
    }

    public void setRemind(String remind) {
        this.remind = remind;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrithday() {
        return brithday;
    }

    public void setBrithday(String brithday) {
        this.brithday = brithday;
    }
    public BrithDay() { }
    public BrithDay(String name, String phone, String brith, String remind, String music, String photo,String remarks) {
        this.name = name;
        this.telephone = phone;
        this.brithday = brith;
        this.remind = remind;
        this.music = music;
        this.photo = photo;
        this.remarks = remarks;
    }
}
