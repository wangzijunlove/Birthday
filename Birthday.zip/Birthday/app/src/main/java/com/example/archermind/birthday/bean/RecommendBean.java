package com.example.archermind.birthday.bean;

import android.content.Context;

import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.factory.TypeFactory;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.List;


public class RecommendBean implements Visitable {
    /**
     * 工厂类返回对应itembean的类型
     */

    private List<Recommendedgift> list_data = new ArrayList<>();
    private Context mContext;

    public List<Recommendedgift> getList_data() {
        return list_data;
    }

    public void setList_data(List<Recommendedgift> list_data) {
        this.list_data = list_data;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public RecommendBean(List<Recommendedgift> must, Context context) {
        mContext = context;
        list_data = must;
    }

    @Override
    public int type(TypeFactory typeFactory) {
        return typeFactory.type(this);
    }
}
