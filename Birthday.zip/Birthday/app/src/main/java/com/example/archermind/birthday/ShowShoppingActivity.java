package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.preference.TwoStatePreference;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Message;
import android.os.Handler;
import android.os.AsyncTask;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.archermind.birthday.adapter.ShoppingAdapter;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.List;

public class ShowShoppingActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    public List<Recommendedgift> list_data = new ArrayList<>();
    private ShoppingAdapter adapter;
    private String TAG = "ShowShoppingActivity";
    DatabaseManger manger;
    public static String flag;
    private TextView textView_title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_shopping);
        Intent intent = getIntent();
        textView_title = findViewById(R.id.tv_person_show_shopping_title);
        flag = intent.getStringExtra("flag");
        recyclerView = findViewById(R.id.recy_person_shopping);
        LinearLayoutManager manager = new LinearLayoutManager(ShowShoppingActivity.this);
        adapter = new ShoppingAdapter(ShowShoppingActivity.this, list_data);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        new UpdateDate().execute(flag);
        OnClick();
        Log.e("--------------", " ------------------" + list_data.size());
    }


    /**
     * 异步的数据加载
     */
    private class UpdateDate extends AsyncTask<String, Void, List<Recommendedgift>>{

        /**
         * 子线程做耗时操作
         * @param strings
         * @return
         */
        @Override
        protected List<Recommendedgift> doInBackground(String... strings) {
            List<Recommendedgift> list_shopping_data = new ArrayList<>();
            if (flag.equals("shopping")) {
                textView_title.setText("购物车");
                manger = new DatabaseManger(ShowShoppingActivity.this);
                String sql = "select *from commodity where shopping > 0 ";
                try {
                    list_shopping_data = manger.query2List(sql, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                manger.close();
            } else if (flag.equals("collection")) {
                textView_title.setText("收藏");
                manger = new DatabaseManger(ShowShoppingActivity.this);
                String sql = "select *from commodity where collection > 0 ";
                try {
                    list_shopping_data = manger.query2List(sql, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                manger.close();
            }
            return list_shopping_data;
        }

        /**
         * 更新UI线程
         * @param recommendedgifts  doInBackground返回的数据
         */
        @Override
        protected void onPostExecute(List<Recommendedgift> recommendedgifts) {
            super.onPostExecute(recommendedgifts);
            list_data.clear();
            list_data.addAll(recommendedgifts);
            Log.e("--------------", " dfafdfasdfdsfdsa" + list_data.size());
            adapter.notifyDataSetChanged();
        }
    }

/*    public class MyThread extends Thread {
        @Override
        public void run() {
            super.run();
            if (flag.equals("shopping")) {
                textView_title.setText("购物车");
                List<Recommendedgift> list_shopping_data = new ArrayList<>();
                manger = new DatabaseManger(ShowShoppingActivity.this);
                String sql = "select *from commodity where shopping > 0 ";
                try {
                    list_shopping_data = manger.query2List(sql, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                manger.close();
                Message msg = mHandler.obtainMessage(1);
                Bundle bundle = new Bundle();
                ArrayList arrayList = new ArrayList();
                arrayList.add(list_shopping_data);
                bundle.putStringArrayList("shopping", arrayList);
                msg.setData(bundle);
                mHandler.sendMessage(msg);
            } else if (flag.equals("collection")) {
                textView_title.setText("收藏");
                List<Recommendedgift> list_collection_data = new ArrayList<>();
                manger = new DatabaseManger(ShowShoppingActivity.this);
                String sql = "select *from commodity where collection > 0 ";
                try {
                    list_collection_data = manger.query2List(sql, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                manger.close();
                Message msg = mHandler.obtainMessage(2);
                Bundle bundle = new Bundle();
                ArrayList arrayList = new ArrayList();
                arrayList.add(list_collection_data);
                bundle.putStringArrayList("collection", arrayList);
                msg.setData(bundle);
                mHandler.sendMessage(msg);
            }


        }
    }

    @SuppressLint("HandlerLeak")
    public Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    Log.e("--------------", "update" + list_data.size());
                    list_data.clear();
                    ArrayList blesingleRet = msg.getData().getParcelableArrayList("shopping");
                    list_data = (List<Recommendedgift>) blesingleRet.get(0);
                    Log.e("--------------", "update" + list_data.size());
                    LinearLayoutManager manager = new LinearLayoutManager(ShowShoppingActivity.this);
                    adapter = new ShoppingAdapter(ShowShoppingActivity.this, list_data);
                    recyclerView.setLayoutManager(manager);
                    recyclerView.setAdapter(adapter);
//                    adapter.notifyDataSetChanged();
                    break;
                case 2:
                    ArrayList collection = msg.getData().getParcelableArrayList("collection");
                    list_data = (List<Recommendedgift>) collection.get(0);
                    adapter = new ShoppingAdapter(ShowShoppingActivity.this, list_data);
                    LinearLayoutManager manager1 = new LinearLayoutManager(ShowShoppingActivity.this);
                    recyclerView.setLayoutManager(manager1);
                    recyclerView.setAdapter(adapter);
                    break;

            }

        }
    };*/

    private void OnClick() {
        adapter.setOnRecyclerViewItemListener(new ShoppingAdapter.OnRecyclerViewItemListener() {
            @Override
            public void onItemClickListener(View view, int position) {
//                adapter.setSelectItem(position);
                Intent intent = new Intent(ShowShoppingActivity.this,ShowCommodityActivity.class);
                intent.putExtra("name", list_data.get(position).getTitle());
                intent.putExtra("price",list_data.get(position).getPrice() );
                intent.putExtra("descibe", list_data.get(position).getDecribe());
                intent.putExtra("photo",list_data.get(position).getImageurl() );
                startActivity(intent);
            }

            /**
             * 长点击事件，长点击删除
             * @param view
             * @param position
             */
            @Override
            public void onItemLongClickListener(View view, final int position) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ShowShoppingActivity.this);
                builder.setIcon(R.drawable.birthday);
                builder.setTitle("弹出警告框");
                builder.setMessage("确定删除吗？");
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.e("------------", "" + position + "  " + which + "    " + list_data.get(position).getId());
                        if (flag.equals("shopping")) {
                            manger = new DatabaseManger(ShowShoppingActivity.this);
                            String[] bb = new String[0];
                            ContentValues contentValues = null;
                            try {

                                int id = list_data.get(position).getId();
                                Log.e("------------", "" + id);
                                bb = new String[]{String.valueOf(id)};
                                contentValues = new ContentValues();
                                contentValues.put("shopping", 0);
                                list_data.remove(position);
                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e(TAG, "更新失败" + e);
                            }
                            try {
                                manger.updateData("commodity", contentValues, "id=?", bb);
                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e(TAG, "更新失败");
                            }
                            manger.close();
                            adapter.notifyDataSetChanged();
                        } else if (flag.equals("collection")) {
                            DatabaseManger manger = new DatabaseManger(ShowShoppingActivity.this);
                            String[] aa = new String[]{String.valueOf(list_data.get(position).getId())};
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("collection", 0);
                            try {
                                manger.updateData("commodity", contentValues, "id=?", aa);
                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e(TAG, "更新失败");
                            }
                            manger.close();
                            list_data.remove(position);
                            adapter.notifyDataSetChanged();
                        }

                        Toast.makeText(ShowShoppingActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.setNeutralButton("忽略", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ShowShoppingActivity.this, "neutral: " + which, Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });
    }

}

