package com.example.archermind.birthday.adapter;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 18-8-17.
 */

public class ShowDetailGiftAdapter extends RecyclerView.Adapter<ShowDetailGiftAdapter.MyViewHolder> {
    private String TAG = "ShowDetailGiftAdapter";
    private Context mcontext;
    private List<Recommendedgift> list_data = new ArrayList();

    public ShowDetailGiftAdapter(Context context, List<Recommendedgift> arrayList) {
        this.mcontext = context;
        this.list_data = arrayList;

    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {
        Recommendedgift commodity = list_data.get(i);
        Log.e(TAG, "开始填充数据");
        myViewHolder.old_price.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
        myViewHolder.old_price.setText("$"+String.valueOf(commodity.getPrice()*2));
        myViewHolder.textView_price.setText("$"+String.valueOf(commodity.getPrice()));
        myViewHolder.textView_title.setText((i+1) + "、" + commodity.getTitle());
        myViewHolder.textView_describe.setText(commodity.getDecribe());
        myViewHolder.imageView_commodity.setImageBitmap(commodity.getPhoto());
        myViewHolder.imageView_collection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "收藏数据操作");
                DatabaseManger manger = new DatabaseManger(mcontext);
                String[] aa = new String[]{String.valueOf(list_data.get(i).getId())};
                ContentValues contentValues = new ContentValues();
                contentValues.put("collection", 1);
                try {
                    manger.updateData("commodity",contentValues,"id=?",aa);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "更新失败");
                }
                manger.close();
                myViewHolder.imageView_collection.setImageResource(R.drawable.collectionred);
                Toast.makeText(mcontext, "收藏成功", Toast.LENGTH_SHORT).show();

            }
        });
        myViewHolder.imageView_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "加入购物车数据操作");
                DatabaseManger manger = new DatabaseManger(mcontext);
                String[] bb = new String[]{String.valueOf(list_data.get(i).getId())};
                ContentValues contentValues = new ContentValues();
                contentValues.put("shopping", (list_data.get(i).getShopping()+1));
                try {
                    manger.updateData("commodity",contentValues,"id=?",bb);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "更新失败");
                }
                manger.close();
                myViewHolder.imageView_shopping.setImageResource(R.drawable.shoppingred);
                Toast.makeText(mcontext, "已加入购物车", Toast.LENGTH_SHORT).show();
            }
        });
        myViewHolder.textView_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.doStartApplicationWithPackageName("com.taobao.taobao",mcontext );
                }
            });
        }

        @Override
        public int getItemViewType ( int position){
            return super.getItemViewType(position);
        }

        @Override
        public long getItemId ( int position){
            return super.getItemId(position);
        }


        @Override
        public int getItemCount () {
            return list_data.size();
        }

        @Override
        public MyViewHolder onCreateViewHolder (ViewGroup parent,int viewType){
            // Create a new view by inflating the row item xml.
            final View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.show_detail_commodity_item, parent, false);

            MyViewHolder holder = new MyViewHolder(v);
            if (mOnRecyclerViewItemListener != null) {
                itemOnClick(holder);
                itemOnLongClick(holder);
            }
            return holder;
        }


        public static class MyViewHolder extends RecyclerView.ViewHolder {
            TextView textView_title, textView_describe, textView_price, old_price, textView_shopping;
            ImageView imageView_commodity, imageView_collection, imageView_shopping;

            public MyViewHolder(View itemView) {
                super(itemView);
                textView_title = itemView.findViewById(R.id.tv_commodity_title);
                textView_describe = itemView.findViewById(R.id.tv_commodity_describe);
                textView_price = itemView.findViewById(R.id.tv_commodity_price1);
                old_price = itemView.findViewById(R.id.tv_commodity_price2);
                imageView_commodity = itemView.findViewById(R.id.img_commodity_image);
                imageView_collection = itemView.findViewById(R.id.img_collection);
                imageView_shopping = itemView.findViewById(R.id.img_shopping);
                textView_shopping = itemView.findViewById(R.id.tv_commodity_shopping);
            }
        }


        private void itemOnClick ( final ShowDetailGiftAdapter.MyViewHolder holder){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = holder.getLayoutPosition();
                    mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, pos);
                }
            });
        }
        private void itemOnLongClick ( final ShowDetailGiftAdapter.MyViewHolder holder){
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int pos = holder.getLayoutPosition();
                    mOnRecyclerViewItemListener.onItemLongClickListener(holder.itemView, pos);
                    return true;
                    //  return mOnRecyclerViewItemListener.onItemLongClickListener(v, v.getTag());
                    //返回true是为了防止触发onClick事件
                }
            });
        }
        public interface OnRecyclerViewItemListener {
            public void onItemClickListener(View view, int position);

            public void onItemLongClickListener(View view, int position);
        }

        private OnRecyclerViewItemListener mOnRecyclerViewItemListener;

        public void setOnRecyclerViewItemListener (OnRecyclerViewItemListener listener){
            mOnRecyclerViewItemListener = listener;
        }
    }
