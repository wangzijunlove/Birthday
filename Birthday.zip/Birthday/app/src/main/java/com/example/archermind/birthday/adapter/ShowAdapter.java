package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.util.Cakeflower;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Showgift;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 18-8-17.
 */

public class ShowAdapter extends RecyclerView.Adapter<ShowAdapter.MyViewHolder>  {
    private  Context mcontext;
    private  List<Cakeflower> list_data= new ArrayList();
    public ShowAdapter(Context context, List<Cakeflower> arrayList){
        this.mcontext=context;
        this.list_data=arrayList;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {
        Cakeflower show=list_data.get(i);
        myViewHolder.imageView.setImageBitmap(show.getPhoto());
        myViewHolder.textView_name.setText(show.getName());
        myViewHolder.textView_price.setText(String.valueOf(show.getPrice()));
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }


    @Override
    public int getItemCount() {
        return list_data.size();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Create a new view by inflating the row item xml.
        final View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_show_item, parent, false);

        MyViewHolder holder = new MyViewHolder(v);
        if (mOnRecyclerViewItemListener != null){
            itemOnClick(holder);
            itemOnLongClick(holder);
        }
        return holder;
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView_name,textView_price;
        ImageView imageView;
        public MyViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_home_show);
            textView_name = itemView.findViewById(R.id.tv_home_cakename);
            textView_price = itemView.findViewById(R.id.tv_home_price);
        }
    }


    private void itemOnClick(final ShowAdapter.MyViewHolder holder){
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, pos);
            }
        });
    }
    private void itemOnLongClick(final ShowAdapter.MyViewHolder holder){
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemLongClickListener(holder.itemView, pos);
                return true;
                //  return mOnRecyclerViewItemListener.onItemLongClickListener(v, v.getTag());
                //返回true是为了防止触发onClick事件
            }
        });
    }
    public interface OnRecyclerViewItemListener {
        public void onItemClickListener(View view, int position);
        public void onItemLongClickListener(View view, int position);
    }

    private OnRecyclerViewItemListener mOnRecyclerViewItemListener;

    public void setOnRecyclerViewItemListener(OnRecyclerViewItemListener listener){
        mOnRecyclerViewItemListener = listener;
    }
}
