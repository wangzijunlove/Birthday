package com.example.archermind.birthday.viewholder;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.example.archermind.birthday.R;
import com.example.archermind.birthday.adapter.ViewPagerAdapter;
import com.example.archermind.birthday.bean.Sowingmap;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.os.Handler;

import butterknife.Bind;
import butterknife.ButterKnife;

public class SowingmapViewHolder extends BaseViewHolder {
    @Bind(R.id.v_dot0) View view1;
    @Bind(R.id.v_dot1) View view2;
    @Bind(R.id.v_dot2) View view3;
    @Bind(R.id.v_dot3) View view4;
    @Bind(R.id.v_dot4) View view5;
    @Bind(R.id.viewpager)  ViewPager viewPager; // android-support-v4中的滑动组件
    public static List<ImageView> imageViews; // 滑动的图片集合
    private Context mContext;
    public static int[] imageResId; // 图片ID
    private List<View> dots; // 图片标题正文的那些点
    private int currentItem = 0; // 当前图片的索引号
    private ScheduledExecutorService scheduledExecutorService;
    @Override
    public void bindViewData(Object data) {
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 2, 2,
                TimeUnit.SECONDS);
        mContext = ((Sowingmap)data).getmContext();
        imageResId = new int[]{R.mipmap.aa, R.mipmap.bb,
                R.mipmap.cc, R.mipmap.dd,
                R.mipmap.ee,0};

        imageViews = new ArrayList<ImageView>();

        for (int i = 0; i < imageResId.length; i++) {

            ImageView imageView = new ImageView(mContext);
            imageView.setImageResource(imageResId[i]);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageViews.add(imageView);

        }

        dots = new ArrayList<View>();

        dots.add(view1);
        dots.add(view2);
        dots.add(view3);
        dots.add(view4);
        dots.add(view5);

        viewPager.setAdapter(new ViewPagerAdapter());
        viewPager.setOnPageChangeListener(new MyPageChangeListener());
    }
//    public SowingmapViewHolder(View itemview){
//        super(itemview);
//        ButterKnife.bind(this, itemview);
//    }
    private class MyPageChangeListener implements ViewPager.OnPageChangeListener {
        private int oldPosition = 0;

        /**
         * This method will be invoked when a new page becomes selected.
         * position: Position index of the new selected page.
         */
        public void onPageSelected(int position) {
            if(position < 5){
                currentItem = position;
                dots.get(oldPosition).setBackgroundResource(R.drawable.dot_normal);
                dots.get(position).setBackgroundResource(R.drawable.dot_focused);
                oldPosition = position;
            }

        }

        public void onPageScrollStateChanged(int arg0) {

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }
    }

    private class ScrollTask implements Runnable {

        public void run() {
            synchronized (viewPager) {
                System.out.println("currentItem: " + currentItem);
                currentItem = (currentItem + 1) % imageViews.size();
                handler.obtainMessage().sendToTarget();
            }
        }

    }

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
//            viewPager.setCurrentItem(currentItem);// 切换当前显示的图片
            if (imageViews.get(currentItem).getParent() != null) {
                if ((currentItem + 1 )== imageViews.size()) {
                    viewPager.setCurrentItem(0);
                } else {

                    ((ViewGroup) viewPager.getParent()).removeView(imageViews.get(currentItem));
                    viewPager.setCurrentItem(currentItem);// 切换当前显示的图片
                }
            }

        };
    };


    public SowingmapViewHolder(View itemview){
        super(itemview);
        ButterKnife.bind(this, itemview);
    }
}
