package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 18-8-17.
 */

public class GiftAdapter extends RecyclerView.Adapter<GiftAdapter.MyViewHolder>  {
    private  Context mcontext;
    private  List<Recommendedgift> list_data= new ArrayList();
    public GiftAdapter(Context context, List<Recommendedgift> arrayList){
        this.mcontext=context;
        this.list_data=arrayList;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {
        Recommendedgift city=list_data.get(i);
         myViewHolder.textView.setText(city.getTitle());
         myViewHolder.imageView.setImageBitmap(city.getPhoto());
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }


    @Override
    public int getItemCount() {
        return list_data.size();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Create a new view by inflating the row item xml.
        final View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_gift_item, parent, false);

        MyViewHolder holder = new MyViewHolder(v);
        if (mOnRecyclerViewItemListener != null){
            itemOnClick(holder);
            itemOnLongClick(holder);
        }
        return holder;
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        View view;
        ImageView imageView;
        public MyViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_gift);
            textView = itemView.findViewById(R.id.tv_title);
            view = itemView.findViewById(R.id.layout_pic);
        }
    }


    private void itemOnClick(final GiftAdapter.MyViewHolder holder){
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, pos);
            }
        });
    }
    private void itemOnLongClick(final GiftAdapter.MyViewHolder holder){
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int pos = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemLongClickListener(holder.itemView, pos);
                return true;
                //  return mOnRecyclerViewItemListener.onItemLongClickListener(v, v.getTag());
                //返回true是为了防止触发onClick事件
            }
        });
    }
    public interface OnRecyclerViewItemListener {
        public void onItemClickListener(View view, int position);
        public void onItemLongClickListener(View view, int position);
    }

    private OnRecyclerViewItemListener mOnRecyclerViewItemListener;

    public void setOnRecyclerViewItemListener(OnRecyclerViewItemListener listener){
        mOnRecyclerViewItemListener = listener;
    }
}
