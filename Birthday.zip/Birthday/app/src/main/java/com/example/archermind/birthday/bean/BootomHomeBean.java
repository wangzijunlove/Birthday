package com.example.archermind.birthday.bean;

import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.factory.TypeFactory;

public class BootomHomeBean implements Visitable {
    @Override
    public int type(TypeFactory typeFactory) {
       return typeFactory.type(this);
    }
}
