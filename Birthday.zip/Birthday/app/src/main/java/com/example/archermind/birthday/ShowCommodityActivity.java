package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.util.Utils;

public class ShowCommodityActivity extends AppCompatActivity {
    private TextView tv_name,tv_title,tv_price,tv_describe,tv_shopping;
    private ImageView img_photo;
    private Button button_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_commodity);
        init();

        button_back = findViewById(R.id.show_commodity_back);
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void init(){
        tv_name = findViewById(R.id.show_commodity_name);
        tv_describe = findViewById(R.id.show_commodity_describe);
        tv_price = findViewById(R.id.show_commodity_price);
        tv_title = findViewById(R.id.show_commodity_title);
        tv_shopping = findViewById(R.id.tv_shopping);
        img_photo = findViewById(R.id.img_commodity_photo);

        final Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String descibe = intent.getStringExtra("descibe");
        int price = intent.getIntExtra("price",-1 );
        String photo = intent.getStringExtra("photo");

        tv_title.setText(name);
        tv_price.setText("$"+price);
        tv_describe.setText(descibe);
        tv_name.setText(name);
        img_photo.setImageBitmap(Utils.getPhoto(photo));
        tv_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.doStartApplicationWithPackageName("com.taobao.taobao",ShowCommodityActivity.this );
            }
        });
    }
}
