package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;

import com.example.archermind.birthday.adapter.MulitAdpter;
import com.example.archermind.birthday.bean.BootomHomeBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.bean.ShowlistBean;
import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Showgift;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ShowGiftListActivity extends AppCompatActivity {
    public static final int TYPE_SHOW_GIFTLIST_EAT = 0x01;
    public static final int TYPE_SHOW_GIFTLIST_CREATE = 0x02;
    public static final int TYPE_SHOW_GIFTLIST_BABY = 0x03;
    public static final int TYPE_SHOW_GIFTLIST_DECORATION = 0x04;
    public static final int TYPE_SHOW_GIFTLIST_HEALTH = 0x05;
    public static final int TYPE_SHOW_GIFTLIST_HOUSE = 0x06;
    private RecyclerView recyclerView;
    private DatabaseManger manger;
    String sort = null;
    List<Recommendedgift> list_data = new ArrayList<>();
    private ImageView imageView_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_gift_list);
        init();
        imageView_back = findViewById(R.id.img_no1);
        imageView_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
    }

    private void init() {
        recyclerView = findViewById(R.id.recy_gift_showlist);
        List<Visitable> beans = new ArrayList<>();
//        beans.add(new MainBean());

//        beans.add(new ContentBean());
//        beans.add(new BootomHomeBean());

        /**
         * 通过传递的flag的值，通过sort字段从数据库中加载数据
         */
        Intent intent = getIntent();
        int flag = intent.getIntExtra("flag", -1);
        if (flag == TYPE_SHOW_GIFTLIST_EAT) {
            sort = "eat";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_EAT));
        } else if (flag == TYPE_SHOW_GIFTLIST_CREATE) {
            sort = "create";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_CREATE));
        } else if (flag == TYPE_SHOW_GIFTLIST_BABY) {
            sort = "baby";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_BABY));
        } else if (flag == TYPE_SHOW_GIFTLIST_DECORATION) {
            sort = "love";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_DECORATION));
        } else if (flag == TYPE_SHOW_GIFTLIST_HEALTH) {
            sort = "health";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_HEALTH));
        } else if (flag == TYPE_SHOW_GIFTLIST_HOUSE) {
            sort = "house";
            getData();
            beans.add(new ShowlistBean(ShowGiftListActivity.this, list_data, TYPE_SHOW_GIFTLIST_HOUSE));
        }

        MulitAdpter multiRecyclerAdapter = new MulitAdpter(beans);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(ShowGiftListActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(multiRecyclerAdapter);
    }

    /**
     * 加载数据库的数据
     */
    private void getData(){
        manger = new DatabaseManger(ShowGiftListActivity.this);
        String sql = "select *from classification where sort = '" + sort + "' ";
        try {
            list_data = manger.queryList(sql, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
