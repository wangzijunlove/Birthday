package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WelcomeActivity extends AppCompatActivity {
    private String TAG = "WelcomeActivity";
    private final int TYPE_WELCOME = 0x01;
    public static List<Recommendedgift> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        if (Utils.getUserInfo(WelcomeActivity.this).get("status").equals("已登录")) {
            mHandler.sendEmptyMessageDelayed(TYPE_WELCOME, 2000);  //已登录延迟两秒发生消息
        }else if(Utils.getUserInfo(WelcomeActivity.this).get("status").equals("未登录")){
             startActivity(new Intent(WelcomeActivity.this,LoginActivity.class));  //未登录跳转到登录界面
        }


    }

    /**
     * 在Handler中登录等待的机制处理
     */
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            int type = msg.what;
            switch (type) {
                case TYPE_WELCOME:
                    Intent mainIntent = new Intent(WelcomeActivity.this, BottomActivity.class);
                    WelcomeActivity.this.startActivity(mainIntent);
                    WelcomeActivity.this.finish();
                default:
                    Log.d(TAG, "should not get here!!!");
                    break;
            }
        }
    };


//    public class MyThread extends Thread{
//        @Override
//        public void run() {
//            super.run();
//            DatabaseManger manger = new DatabaseManger(WelcomeActivity.this);
//            String sql = "select *from classification where id > 22 ";
//            try {
//                list = manger.queryList(sql, null);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            manger.close();
//        }
//    }
}
