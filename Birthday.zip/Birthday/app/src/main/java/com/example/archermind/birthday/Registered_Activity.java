package com.example.archermind.birthday;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.archermind.birthday.util.Utils;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Registered_Activity extends AppCompatActivity {
    private EditText text_name, text_password, text_password_again;
    private TextView btn_registered;
    private Boolean Registered_status = false;
    OkHttpClient client = new OkHttpClient();
    String url = "http://47.101.209.193:8080/birthday/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered_);
        init();

    }

    private void init() {
        text_name = findViewById(R.id.edit_registered_name);
        text_password = findViewById(R.id.edit_registered_password);
        text_password_again = findViewById(R.id.edit_registered_password_again);
        btn_registered = findViewById(R.id.tv_registered_registered);
//        name = Utils.getUserInfo(Registered_Activity.this).get("name");
    }

    private Boolean Registered() {
        btn_registered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (name.equals(text_name.getText().toString())){
//                    Registered_status = false;
//                    Toast.makeText(Registered_Activity.this, "用户以及存在", Toast.LENGTH_SHORT).show();
//                }else
                if (!(text_password.getText().toString().equals(text_password_again.getText().toString()))) {
                    Registered_status = false;
                    Toast.makeText(Registered_Activity.this, "两次密码不一致", Toast.LENGTH_SHORT).show();
                    text_password.getText().clear();
                    text_password_again.getText().clear();
                } else {
                    doPost(v);
                }
            }
        });
        return Registered_status;
    }

    public void doPost(View view) {
        String name = text_name.getText().toString();
        String pass = text_password.getText().toString();
        FormBody formBody = new FormBody.Builder()
                .add("name", name)
                .add("password", pass)
                .build();

        Request.Builder builder = new Request.Builder();
        final Request request = builder.url(url + "RegisteredAction").post(formBody).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("OkHttpActivity", "访问失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
//                Log.e("OKHttpActivity", "  " + response.body().string());
                String result = response.body().string();
                Log.e("OKHttpActivity", "  " + result);
                Message message = mHandler.obtainMessage();
                message.what = 1;
                message.obj = result;
                mHandler.sendMessage(message);

            }
        });
    }



    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 1){
                String result = msg.obj.toString();
                if (result.equals("1")) {
                    Toast.makeText(Registered_Activity.this, "用户已存在", Toast.LENGTH_SHORT).show();
                    text_password.getText().clear();
                    text_password_again.getText().clear();
                    text_name.getText().clear();
                } else if (result.equals("0")) {
                    Registered_status = true;
                    Utils.saveUserInfo(Registered_Activity.this, text_name.getText().toString(), text_password.getText().toString(), false);
                    startActivity(new Intent(Registered_Activity.this, LoginActivity.class));
                    Toast.makeText(Registered_Activity.this, "注册成功", Toast.LENGTH_SHORT).show();
                }
            }
            super.handleMessage(msg);
        }
    };
}
