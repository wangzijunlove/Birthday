package com.example.archermind.birthday.util;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.provider.ContactsContract;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.WindowManager;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Utils {
    private static  Bitmap photo;
    public static int dp2px(Context context, float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                dp, context.getResources().getDisplayMetrics());
    }

    /**
     * 获得屏幕宽度
     *
     * @param context
     * @return
     */
    public static int getScreenWidth(Context context) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }

    /**
     * 获得屏幕高度
     *
     * @param context
     * @return
     */
    public static int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.heightPixels;
    }

    public static boolean saveInfo(Context context, String City, String Address) {
        SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("city", City);
        edit.putString("address", Address);
        // edit.putInt("zwn", 22);
        Log.e("Savemessage", City + "---" + Address);
        edit.commit();
        return true;
    }


    //使用Map<>方法从data.xml文件中获取数据
    public static Map<String, String> getInfo(Context context) {
        SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        String city = sp.getString("city", null);
        String address = sp.getString("address", null);
        Log.e("getMessage ", city + "---" + address);
        Map<String, String> userMap = new HashMap<String, String>();
        userMap.put("city", city);
        userMap.put("address", address);
        return userMap;
    }

    public static boolean savebirthdayInfo(Context context, String name) {
        SharedPreferences sp = context.getSharedPreferences("birthday", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("name", name);
        edit.commit();
        return true;
    }


    //使用Map<>方法从data.xml文件中获取数据
    public static String getbirthdayInfo(Context context) {
        SharedPreferences sp = context.getSharedPreferences("birthday", Context.MODE_PRIVATE);
        String name = sp.getString("name", null);
        return name;
    }

    public static Map<String, String> getUserInfo(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        String name = sp.getString("name", null);
        String password = sp.getString("password", null);
        Boolean Status = sp.getBoolean("status", false);
        String Login_status = null;
        if (Status) {
            Login_status = "已登录";
        } else {
            Login_status = "未登录";
        }
        Log.e("getMessage ", name + "---" + password);
        Map<String, String> userMap = new HashMap<String, String>();
        userMap.put("name", name);
        userMap.put("password", password);
        userMap.put("status", Login_status);
        return userMap;
    }

    public static boolean saveUserInfo(Context context, String name, String password, Boolean Status) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("name", name);
        edit.putString("password", password);
        edit.putBoolean("status", Status);
        // edit.putInt("zwn", 22);
        Log.e("Savemessage", name + "---" + password);
        edit.commit();
        return true;
    }

    public static Bitmap getRoundBitmap(Bitmap bitmap, int roundPx) {
        Paint paint = new Paint();
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;

        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        int x = bitmap.getWidth();

        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;


    }

    public static Bitmap drawableToBitmap(Drawable drawable) {


        Bitmap bitmap = Bitmap.createBitmap(

                drawable.getIntrinsicWidth(),

                drawable.getIntrinsicHeight(),

                drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888

                        : Bitmap.Config.RGB_565);

        Canvas canvas = new Canvas(bitmap);

        //canvas.setBitmap(bitmap);

        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());

        drawable.draw(canvas);

        return bitmap;

    }


    public static Bitmap getCroppedBitmap(Bitmap bmp, int radius) {
        Bitmap sbmp;
        if (bmp.getWidth() != radius || bmp.getHeight() != radius)
            sbmp = Bitmap.createScaledBitmap(bmp, radius, radius, false);
        else
            sbmp = bmp;

        Bitmap output = Bitmap.createBitmap(sbmp.getWidth(), sbmp.getHeight(), Bitmap.Config.ARGB_8888);
        final Rect rect = new Rect(0, 0, sbmp.getWidth(), sbmp.getHeight());

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);
        paint.setColor(Color.parseColor("#BAB399"));

        Canvas c = new Canvas(output);
        c.drawARGB(0, 0, 0, 0);
        c.drawCircle(sbmp.getWidth() / 2 + 0.7f, sbmp.getHeight() / 2 + 0.7f, sbmp.getWidth() / 2 + 0.1f, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        c.drawBitmap(sbmp, rect, rect, paint);

        return output;
    }


    public static Bitmap getPhoto(String url) {
        File file = new File(url);
        Bitmap bm = null;
        Log.e("-----------------", "" + file);
        if (file.exists()) {
            bm = BitmapFactory.decodeFile(url);
            Log.e("------------", "" + bm);
        }
        return bm;

    }

    public static void doStartApplicationWithPackageName(String packagename, Context context) {
        PackageInfo packageinfo = null;
        try {
            packageinfo = context.getPackageManager().getPackageInfo(packagename, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (packageinfo == null) {
            return;
        }
        Intent resolveIntent = new Intent(Intent.ACTION_MAIN, null);
        resolveIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        resolveIntent.setPackage(packageinfo.packageName);
        List<ResolveInfo> resolveinfoList = context.getPackageManager().queryIntentActivities(resolveIntent, 0);
        ResolveInfo resolveinfo = resolveinfoList.iterator().next();
        if (resolveinfo != null) {
            String packageName = resolveinfo.activityInfo.packageName;
            String className = resolveinfo.activityInfo.name;
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            ComponentName cn = new ComponentName(packageName, className);
            intent.setComponent(cn);
            context.startActivity(intent);
        }
    }

    public static int getTimeDifferent(Date Birthday, Date Cur) {
        int TimeDifferent = 0;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(Cur);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int data = calendar.get(Calendar.DAY_OF_YEAR);

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(Birthday);
        int year_birth = calendar1.get(Calendar.YEAR);
        int month_birth = calendar1.get(Calendar.MONTH);
        int day_birth = calendar1.get(Calendar.DAY_OF_MONTH);
        int data_birth = calendar1.get(Calendar.DAY_OF_YEAR);
        if (month - month_birth < 0) {
            // 小于零代表今年生日还没过
            TimeDifferent = data_birth - data;
        } else if (month == month_birth) {
            if (day == day_birth) {
                TimeDifferent = 0;
            } else if (day < day_birth) {
                TimeDifferent = day_birth - day;
            } else {
                if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
                    TimeDifferent = 366 - data + data_birth;
                } else {
                    TimeDifferent = 365 - data + data_birth;
                }
            }

        } else {
            if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
                TimeDifferent = 366 - data + data_birth;
            } else {
                TimeDifferent = 365 - data + data_birth;
            }
        }
//        Time t=new Time(); // or Time t=new Time("GMT+8"); 加上Time Zone资料
//        t.setToNow();
//        Log.e("--------------------",""+t.isDst+"  "+t.month+"     "+t.monthDay+ "   "+t.year+"   "+t.yearDay+"  "+t.allDay);
//        if(curMonth - oldMonth < 0 ){
//            // 小于零代表今年生日还没过
//            int diff = oldMonth - curMonth;
//            for(int i = 0; i < oldMonth - curMonth; i++){
//                if(curMonth == 1 || curMonth ==3 || curMonth ==5 || curMonth ==7 || curMonth ==8 || curMonth ==10 || curMonth ==12 ){
//                    MonthDifferent = 31 - curDay;
//                }else if(curMonth == 2){
//                    if(curYear%400==0||(curYear%4==0&&curYear%100!=0)){
//                        MonthDifferent = 29 - curDay;
//                    }else {
//                        MonthDifferent = 28 - curDay;
//                    }
//                }else {
//                    MonthDifferent = 30 - curDay;
//                }
//                curMonth++;
////                Log.e("--------------------",""+MonthDifferent+"     "+curMonth);
//            }
//
//            TimeDifferent = MonthDifferent + oldDay;
//        }else if(curMonth - oldMonth == 0 ){
//            if(curDay - oldDay < 0){
//                TimeDifferent = oldDay - curDay;
//            }else {
//                TimeDifferent = -1;
//            }
//        }else {
//            TimeDifferent = -1;
//        }
        Log.e("-----------------------", "" + TimeDifferent);
        return TimeDifferent;
    }

    public static Bitmap decodeBitmap(String path) {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(path, op); //获取尺寸信息
        //获取比例大小
        //int height = op.outHeight * 100 / op.outWidth;
        op.inSampleSize = op.outHeight / 200;
        op.inJustDecodeBounds = false;
        bmp = BitmapFactory.decodeFile(path, null);
        return bmp;
    }

    public static Date ConverToDate(String strDate) throws Exception {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        return df.parse(strDate);
    }

//    public static void getImageURL(List<Recommendedgift> list) {
//        //开启一个线程用于联网
//        final String path;
//        new Thread() {
//            @Override
//            public void run() {
//                try {
//                    //把传过来的路径转成URL
//                    URL url = new URL(path);
//                    //获取连接
//                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                    //使用GET方法访问网络
//                    connection.setRequestMethod("GET");
//                    //超时时间为10秒
//                    connection.setConnectTimeout(10000);
//                    //获取返回码
//                    int code = connection.getResponseCode();
//                    if (code == 200) {
//                        InputStream inputStream = connection.getInputStream();
//                        //使用工厂把网络的输入流生产Bitmap
//                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
//
//                        //利用Message把图片发给Handler
//                        inputStream.close();
//                    }else {
//                        //服务启发生错误
////                        handler.sendEmptyMessage(SERVER_ERROR);
//                    }
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    //网络连接错误
////                    handler.sendEmptyMessage(NETWORK_ERROR);
//                }
//            }
//        }.start();
//    }

}