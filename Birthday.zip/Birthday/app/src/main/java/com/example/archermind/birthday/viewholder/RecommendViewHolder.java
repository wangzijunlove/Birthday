package com.example.archermind.birthday.viewholder;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowCakeFlowerActivity;
import com.example.archermind.birthday.ShowDetailGiftActivity;
import com.example.archermind.birthday.adapter.GiftAdapter;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.fragment.Fragment2;
import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.GridDividerItemDecoration;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class RecommendViewHolder extends BaseViewHolder {
    @Bind(R.id.recy_navigation)
    RecyclerView recyclerView;
    @Bind(R.id.img_festival)
    ImageView imageView_festival;
    @Bind(R.id.layout_tuisong) View view_cake;
    @Bind(R.id.layout_tuisong2) View view_flower;
    @Bind(R.id.tv_birthdayname)
    TextView textView_name;
    private Context mContext;
    private static List<Recommendedgift> list = new ArrayList<>();
    @Override
    public void bindViewData(Object data) {
        mContext = ((RecommendBean)data).getmContext();
        GiftAdapter giftAdapter = new GiftAdapter( ((RecommendBean)data).getmContext(), ((RecommendBean)data).getList_data());
        list =  ((RecommendBean)data).getList_data();
        GridLayoutManager layoutManager = new GridLayoutManager(((RecommendBean)data).getmContext(), 2);
        recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 20));
        recyclerView.setLayoutManager(layoutManager);
//            recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 1));
        recyclerView.setAdapter(giftAdapter);
        if(Utils.getbirthdayInfo(mContext) != null){
            textView_name.setText("好友 "+Utils.getbirthdayInfo(mContext));
        }
        giftAdapter.setOnRecyclerViewItemListener(new GiftAdapter.OnRecyclerViewItemListener() {
            @Override
            public void onItemClickListener(View view, int position) {
                Log.e("----点击事件----", "onTouch"+position);
                Intent intent  = new Intent(mContext, ShowDetailGiftActivity.class);
                intent.putExtra("flag", ShowDetailGiftActivity.TYPE_SHOW_GIFTDETAIL_MUST_GIFT);
                intent.putExtra("position", position);
                mContext.startActivity(intent);
            }

            @Override
            public void onItemLongClickListener(View view, int position) {

            }
        });
        imageView_festival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("----点击事件----", "onTouch圣诞节图片");
                Intent intent  = new Intent(mContext, ShowDetailGiftActivity.class);
                intent.putExtra("flag", ShowDetailGiftActivity.TYPE_SHOW_GIFTDETAIL_FESTIVAL);
                mContext.startActivity(intent);

            }
        });

        view_cake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("----点击事件----", "onTouch蛋糕");
                Intent intent = new Intent(mContext,ShowCakeFlowerActivity.class);
                intent.putExtra("flag", ShowCakeFlowerActivity.TYPE_SHOW_GIFT_CAKE);
                mContext.startActivity(intent);
            }
        });

        view_flower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("----点击事件----", "onTouch鲜花");
                Intent intent = new Intent(mContext,ShowCakeFlowerActivity.class);
                intent.putExtra("flag", ShowCakeFlowerActivity.TYPE_SHOW_GIFT_FLOWER);
                mContext.startActivity(intent);
            }
        });
    }


    public static List<Recommendedgift> getData(){
        return list;
    }

    public RecommendViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
