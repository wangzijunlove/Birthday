package com.example.archermind.birthday.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.LoginActivity;
import com.example.archermind.birthday.Person_Author_Activity;
import com.example.archermind.birthday.Person_Opinion_Activity;
import com.example.archermind.birthday.Person_Tutorial_Activity;
import com.example.archermind.birthday.R;
import com.example.archermind.birthday.ShowCardActivity;
import com.example.archermind.birthday.ShowOrderActivity;
import com.example.archermind.birthday.ShowPersonActivity;
import com.example.archermind.birthday.ShowShoppingActivity;
import com.example.archermind.birthday.adapter.PeopleAdapter;
import com.example.archermind.birthday.adapter.PhotoAdapter;
import com.example.archermind.birthday.People_update_Activity;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Fragment4 extends Fragment implements View.OnClickListener {
    private List<String> list = new ArrayList<>();
    private View view_person, btn_update, btn_advices, btn_auther, btn_Tutorial;
    private TextView btn_exit;
    private ImageView imageView_shopping, imageView_collection, imageView_card, imageView_order;
    private TextView textView_name, textView_signature;
    private DatabaseManger manger;
    public static Map<String, String> userMap = new HashMap<String, String>();

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_four, container, false);
        view_person = view.findViewById(R.id.layout_xinxi_people);
        view_person.setOnClickListener(this);
        btn_advices = view.findViewById(R.id.layout_people_ad);
        btn_advices.setOnClickListener(this);
        btn_auther = view.findViewById(R.id.layout_people_user);
        btn_auther.setOnClickListener(this);
        btn_update = view.findViewById(R.id.layout_people_up);
        btn_update.setOnClickListener(this);
        btn_Tutorial = view.findViewById(R.id.layout_people_jiaocheng);
        btn_Tutorial.setOnClickListener(this);
        btn_exit = view.findViewById(R.id.tv_people_exit);
        btn_exit.setOnClickListener(this);
        imageView_shopping = view.findViewById(R.id.img_gouwu_people);
        imageView_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ShowShoppingActivity.class);
                intent.putExtra("flag", "shopping");
                startActivity(intent);
            }
        });
        imageView_collection = view.findViewById(R.id.img_shoucang_people);
        imageView_collection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ShowShoppingActivity.class);
                intent.putExtra("flag", "collection");
                startActivity(intent);
            }
        });
        imageView_card = view.findViewById(R.id.img_kajuan_people);
        imageView_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), ShowCardActivity.class));
            }
        });

        imageView_order = view.findViewById(R.id.img_dingdan_people);
        imageView_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), ShowOrderActivity.class));
            }
        });
        userMap = getUserInfo();
        try {
            textView_name = view.findViewById(R.id.btn_name_people);
            textView_name.setText(userMap.get("name"));
            textView_signature = view.findViewById(R.id.btn_signature_people);
            textView_signature.setText(userMap.get("signature"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_people_exit:
                if (Utils.getUserInfo(getContext()).get("status").equals("已登录")) {
                    startActivity(new Intent(getContext(), LoginActivity.class));
                    String name = Utils.getUserInfo(getContext()).get("name");
                    String password = Utils.getUserInfo(getContext()).get("password");
                    Utils.saveUserInfo(getContext(), name, password, false);
                } else {
                    Intent intent = new Intent(Intent.ACTION_MAIN, null);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    startActivity(intent);
                }
                break;
            case R.id.layout_people_ad:
                startActivity(new Intent(getContext(), Person_Opinion_Activity.class));
                break;
            case R.id.layout_people_up:
                startActivity(new Intent(getContext(), People_update_Activity.class));
                break;
            case R.id.layout_people_user:
                startActivity(new Intent(getContext(), Person_Author_Activity.class));
                break;
            case R.id.layout_people_jiaocheng:
                startActivity(new Intent(getContext(), Person_Tutorial_Activity.class));
                break;
            case R.id.layout_xinxi_people:
                startActivity(new Intent(getContext(), ShowPersonActivity.class));
                break;
        }
    }

    /**
     * 从数据库中加载用户的数据
     *
     * @return
     */
    private Map<String, String> getUserInfo() {
        Map<String, String> user = new HashMap<String, String>();
        manger = new DatabaseManger(getContext());
        String sql = "select *from userinfo";
        try {
            user = manger.queryUserinfo(sql, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        manger.close();
        return user;
    }
}
