package com.example.archermind.birthday;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.archermind.birthday.adapter.BrithDayAdapter;
import com.example.archermind.birthday.sqlhepler.DataBaseHelp;
import com.example.archermind.birthday.adapter.SlideAdapter;
import com.example.archermind.birthday.bean.BootomHomeBean;
import com.example.archermind.birthday.fragment.Fragment1;
import com.example.archermind.birthday.fragment.Fragment2;
import com.example.archermind.birthday.fragment.Fragment3;
import com.example.archermind.birthday.fragment.Fragment4;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.CalendarOpretion;
import com.example.archermind.birthday.util.ToastUtil;

import java.io.IOException;

public class BottomActivity extends AppCompatActivity implements View.OnClickListener, BrithDayAdapter.IonSlidingViewClickListener {
    private BottomNavigationView bottomNavigationView;
    private MenuItem menuItem;
    private Fragment1 fragment1 = new Fragment1();
    private Fragment2 fragment2 = new Fragment2();
    private Fragment3 fragment3 = new Fragment3();
    private Fragment4 fragment4 = new Fragment4();
    private TextView imageView_search;
    private Fragment[] fragments;
    private int lastfragment;
    private DatabaseManger manger;
    private String TAG = "Fragment birthday";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bottom_item);
        Log.e(TAG,"1111111111111111111111111111");

        init();
        DataBaseHelp dbhelp = new DataBaseHelp(this);
        try {
            dbhelp.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 系统回调方法，加载页面是判断是否要加载到特定的fragment
     */
    @Override
    protected void onResume() {
        super.onResume();
//        Intent intent = getIntent();
//        int flag = intent.getIntExtra("flag", 0);
//        if (flag == 1) {
//            switchFragment(lastfragment, 1);
//            lastfragment = 1;
//            bottomNavigationView.setSelectedItemId(bottomNavigationView.getMenu().getItem(1).getItemId());
//        }else if(flag == 3){
//            switchFragment(lastfragment, 3);
//            lastfragment = 3;
//            bottomNavigationView.setSelectedItemId(bottomNavigationView.getMenu().getItem(3).getItemId());
//        }
    }

    /**
     * 菜单的点击事件，通过点击菜单实现fragment
     */
    private BottomNavigationView.OnNavigationItemSelectedListener changeFragment = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Log.d("123", "onNavigationItemSelected is click: ");
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    if (lastfragment != 0) {
                        switchFragment(lastfragment, 0);
                        lastfragment = 0;
                    }
                    return true;
                case R.id.navigation_dashboard:
                    if (lastfragment != 1) {
                        switchFragment(lastfragment, 1);
                        lastfragment = 1;
                    }
                    return true;
                case R.id.navigation_notifications:
                    if (lastfragment != 2) {
                        switchFragment(lastfragment, 2);
                        lastfragment = 2;
                    }
                    return true;
                case R.id.navigation_person:
                    if (lastfragment != 3) {
                        switchFragment(lastfragment, 3);
                        lastfragment = 3;
                    }
                    return true;
            }
            return false;
        }
    };

    /**
     * 初始化操作
     */
    private void init() {
        fragments = new Fragment[]{fragment2, fragment1, fragment3, fragment4};
        lastfragment = 0;
        getSupportFragmentManager().beginTransaction().replace(R.id.layout_frame, fragment2).show(fragment2).commit();
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(changeFragment);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_search_main:

                break;
        }
    }

    /**
     * 切换Framement页面
     * @param lastfragment
     * @param index
     */
    private void switchFragment(int lastfragment, int index) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.hide(fragments[lastfragment]);
        if (fragments[index].isAdded() == false) {
            transaction.add(R.id.layout_frame, fragments[index]);
        }
        transaction.show(fragments[index]).commitAllowingStateLoss();
    }

    /**
     * 手机的按键事件，返回键到主界面
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            home.addCategory(Intent.CATEGORY_HOME);
            startActivity(home);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


//    @Override
//    public void onDeleteCilck(View view, int position) {
//        Log.e("__________________","点击了"+position);
//        startActivity(new Intent(BottomActivity.this,ShowContactActivity.class));
//    }

    /**
     * 侧滑删除
     *
     * @param view
     * @param position
     */
    @Override
    public void onDeleteBtnCilck(View view, int position) {
        manger = new DatabaseManger(BottomActivity.this);
        Log.i("DeleteActivity", "删除项：" + position);
        String[] aa = new String[]{Fragment1.list_brith.get(position).getName()};
        try {
            manger.deleteData("brithday", "name=?", aa);
        } catch (Exception e) {
            e.printStackTrace();
        }
        CalendarOpretion.deleteCalendarEvent(BottomActivity.this, Fragment1.list_brith.get(position).getName() + "生日提醒");
        ToastUtil.showMessage(BottomActivity.this, this.getString(R.string.delete_success));
        Fragment1.list_brith.remove(position);
        Fragment1.mbrithDayAdapter.notifyDataSetChanged();
        manger.close();
    }

    /**
     * 侧滑更新
     * @param view
     * @param position
     */
    @Override
    public void onUpdateBtnClick(View view, int position) {
        Fragment1.flag_opretion = true;
        Bundle bundle = new Bundle();
        bundle.putInt("id", position);
        Intent intent = new Intent(BottomActivity.this, AddFriendActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
        Log.e(TAG, "更新");
    }

    /**
     * Item的单击事件
     * @param view
     * @param position
     */

    @Override
    public void onBtnClick(View view, int position) {
//        Fragment1.flag_opretion = true;
//        Bundle bundle = new Bundle();
//        bundle.putInt("id", position);
//        Intent intent = new Intent(BottomActivity.this, AddFriendActivity.class);
//        intent.putExtras(bundle);
//        startActivity(intent);
//        Log.e(TAG, "更新");
    }

    @Override
    public void onItemClickListener(View view, int position) {
        Log.e(TAG, BottomActivity.this.getString(R.string.single_click));
    }

    @Override
    public void onItemLongClickListener(View view, int position) {
        Log.e(TAG, BottomActivity.this.getString(R.string.long_click));
    }
}
