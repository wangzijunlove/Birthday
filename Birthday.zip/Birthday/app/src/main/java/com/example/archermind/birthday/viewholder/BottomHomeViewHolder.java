package com.example.archermind.birthday.viewholder;

import android.view.View;

import butterknife.ButterKnife;

public class BottomHomeViewHolder extends BaseViewHolder {

    public BottomHomeViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }

    @Override public void bindViewData(Object data) {

    }
}
