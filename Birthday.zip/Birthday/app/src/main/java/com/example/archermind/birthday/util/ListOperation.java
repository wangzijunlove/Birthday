package com.example.archermind.birthday.util;

import java.util.List;

public class ListOperation {
//    public boolean equre(List list,String str){
//        for(int i=0;i<list.size();i++)
//        {
//            if(str.equals(list.get(i))){
//                return false;
//            }
//        }
//        return true;
//
//    }
    public boolean RemoveRepeat(List<Music> list,Music bb){

        for(Music bbb:list)
        {
            if(bbb.getSong_path().equals(bb.getSong_path())){
                return false;
            }
        }
        return true;

    }
}
