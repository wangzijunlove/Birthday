package com.example.archermind.birthday.sqlhepler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;


import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.util.Utils;
import com.example.archermind.birthday.util.Cakeflower;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseManger {
    private DataBaseHelp dbHelper;
    private static DatabaseManger instance = null;
    private SQLiteDatabase sqLiteDatabase;

    /**
     * 构造方法上下文
     *
     * @param context
     * @return
     */
    public DatabaseManger(Context context) {
        dbHelper = new DataBaseHelp(context);
        sqLiteDatabase = dbHelper.getWritableDatabase();
    }

    /**
     * 获取本类对象的实例
     *
     * @param context
     * @return
     */
    public static final DatabaseManger getInstance(Context context) {
        if (instance == null) {
            if (context == null) {
                throw new RuntimeException("Context is null.");

            }
            instance = new DatabaseManger(context);
        }

        return instance;
    }

    /**
     * 关闭数据库
     */
    public void close() {
        if (sqLiteDatabase.isOpen()) {
            sqLiteDatabase.close();
            sqLiteDatabase = null;
        }
        if (dbHelper != null) {
            dbHelper.close();
            dbHelper = null;
        }

        if (instance != null) {
            instance = null;
        }

    }

    /**
     * 执行一条sql语句
     */

    public void execSql(String sql) {
        if (sqLiteDatabase.isOpen()) {
            sqLiteDatabase.execSQL(sql);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
    }

    /**
     * sql执行查询操作的sql语句
     * selectionargs查询条件
     * 返回查询的游标，可对数据进行操作，但是需要自己关闭游标
     */
    public Cursor queryData2Cursor(String sql, String[] selectionArgs) throws Exception {
        Cursor cursor = null;
        if (sqLiteDatabase.isOpen()) {
            cursor = sqLiteDatabase.rawQuery(sql, selectionArgs);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        Log.e("DataBaseMAnger", "---------------cursor1-------------");
        return cursor;
    }

    /**
     * 查询表中数据总条数
     * 返回表中数据条数
     */

    public int getDataCounts(String table) throws Exception {
        Cursor cursor = null;
        int counts = 0;
        if (sqLiteDatabase.isOpen()) {
            cursor = queryData2Cursor("select * from " + table, null);
            if (cursor != null && cursor.moveToFirst()) {
                counts = cursor.getCount();
            }
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        return counts;
    }

    /**
     * 消除表中所有数据
     *
     * @param table
     * @throws Exception
     */
    public void clearAllData(String table) throws Exception {
        if (sqLiteDatabase.isOpen()) {
            execSql("delete from " + table);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
    }

    /**
     * 插入数据
     *
     * @param sql      执行操作的sql语句
     * @param bindArgs sql中的参数，参数的位置对于占位符的顺序
     * @return 返回插入对应的额ID，返回0，则插入无效
     * @throws Exception
     */

    public long insertDataBySql(String sql, String[] bindArgs) throws Exception {
        long id = 0;
        if (sqLiteDatabase.isOpen()) {
            SQLiteStatement sqLiteStatement = sqLiteDatabase.compileStatement(sql);
            if (bindArgs != null) {
                int size = bindArgs.length;
                for (int i = 0; i < size; i++) {
                    sqLiteStatement.bindString(i + 1, bindArgs[i]);
                }
                id = sqLiteStatement.executeInsert();
                sqLiteStatement.close();
            }
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        return id;
    }

    /**
     * 插入数据
     *
     * @param table  表名
     * @param values 数据
     * @return 返回插入的ID，返回0，则插入失败
     * @throws Exception
     */
    public long insetData(String table, ContentValues values) throws Exception {
        long id = 0;
        if (sqLiteDatabase.isOpen()) {
            id = sqLiteDatabase.insertOrThrow(table, null, values);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        return id;
    }

    /**
     * 批量插入数据
     *
     * @param table 表名
     * @param list  数据源
     * @param args  数据键名 key
     * @return
     * @throws Exception
     */
    public long insertBatchData(String table, List<Map<String, Object>> list, String[] args) throws Exception {
        long insertNum = 0;
        sqLiteDatabase.beginTransaction();
        ContentValues contentValues = new ContentValues();
        for (int i = 0; i < list.size(); i++) {
            for (int j = 0; j < args.length; j++) {
                contentValues.put(args[j], list.get(i).get(args[j]).toString());
            }
            long id = insetData(table, contentValues);
            if (id > 0) {
                insertNum++;
            }
        }
        sqLiteDatabase.setTransactionSuccessful();
        sqLiteDatabase.endTransaction();
        return insertNum;
    }

    /**
     * 更新数据
     *
     * @param table        表名
     * @param values       需要更新的数据
     * @param whereClaause 表示sql语句中条件部分的语句
     * @param whereArgs    表示占位符的值
     * @return
     * @throws Exception
     */
    public int updateData(String table, ContentValues values, String whereClaause, String[] whereArgs) throws Exception {
        int rowsNum = 0;
        if (sqLiteDatabase.isOpen()) {
            rowsNum = sqLiteDatabase.update(table, values, whereClaause, whereArgs);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        return rowsNum;
    }

    /**
     * 删除数据
     *
     * @param sql      待执行的sql语句
     * @param bindArgs sql语句中的参数，参数的顺序对应占位符的顺序
     */
    public void deleteDataBySql(String sql, String[] bindArgs) throws Exception {
        if (sqLiteDatabase.isOpen()) {
            SQLiteStatement statement = sqLiteDatabase.compileStatement(sql);
            if (bindArgs != null) {
                int size = bindArgs.length;
                for (int i = 0; i < size; i++) {
                    statement.bindString(i + 1, bindArgs[i]);
                }
                statement.execute();
                statement.close();
            }
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
    }

    /**
     * 删除数据
     *
     * @param table       表名
     * @param whereClause sql中的条件语句部分
     * @param whereArgs   占位符的值
     * @return
     */
    public long deleteData(String table, String whereClause, String[] whereArgs) throws Exception {
        Log.e("TAG", "----deleteDAte----");
        long rowsNum = 0;
        if (sqLiteDatabase.isOpen()) {
            rowsNum = sqLiteDatabase.delete(table, whereClause, whereArgs);
        } else {
            throw new RuntimeException("The DataBase has already closed");
        }
        return rowsNum;
    }

    /**
     * @param table         表名
     * @param columns       查询需要返回的列的字段
     * @param selection     SQL语句中的条件语句
     * @param selectionArgs 占位符的值
     * @param groupBy       表示分组，可以为NULL
     * @param having        SQL语句中的having，可以为null
     * @param orderBy       表示结果排序，可以为null
     * @return
     * @throws Exception
     */
    public Cursor queryData(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) throws Exception {
        return queryData(table, columns, selection, selectionArgs, groupBy, having, orderBy, null);
    }


    /**
     * @param table         表名
     * @param columns       查询需要返回的列的字段
     * @param selection     SQL语句中的条件语句
     * @param selectionArgs 占位符的值
     * @param groupBy       表示分组，可以为NULL
     * @param having        SQL语句中的having，可以为null
     * @param orderBy       表示结果排序，可以为null
     * @param limit         表示分页
     * @return
     * @throws Exception
     */
    public Cursor queryData(String table, String[] columns, String selection, String[] selectionArgs,
                            String groupBy, String having, String orderBy, String limit) throws Exception {
        return queryData(false, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
    }

    /**
     * @param distinct      true if you want each row to be unique,false otherwise
     * @param table         表名
     * @param columns       查询需要返回的列的字段
     * @param selection     SQL语句中的条件语句
     * @param selectionArgs 占位符的值
     * @param groupBy       表示分组，可以为NULL
     * @param having        SQL语句中的having，可以为null
     * @param orderBy       表示结果排序，可以为null
     * @param limit         表示分页
     * @return
     * @throws Exception
     */
    public Cursor queryData(boolean distinct, String table, String[] columns, String selection,
                            String[] selectionArgs, String groupBy,
                            String having, String orderBy, String limit) throws Exception {
        return queryData(null, distinct, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
    }


    /**
     * @param cursorFactory 游标工厂
     * @param distinct      true if you want each row to be unique,false otherwise
     * @param table         表名
     * @param columns       查询需要返回的列的字段
     * @param selection     SQL语句中的条件语句
     * @param selectionArgs 占位符的值
     * @param groupBy       表示分组，可以为NULL
     * @param having        SQL语句中的having，可以为null
     * @param orderBy       表示结果排序，可以为null
     * @param limit         表示分页
     * @return
     * @throws Exception
     */
    public Cursor queryData(SQLiteDatabase.CursorFactory cursorFactory, boolean distinct, String table, String[] columns, String selection,
                            String[] selectionArgs, String groupBy,
                            String having, String orderBy, String limit) throws Exception {
        Cursor cursor = null;
        if (sqLiteDatabase.isOpen()) {
            cursor = sqLiteDatabase.queryWithFactory(cursorFactory, distinct, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
        } else {
            throw new RuntimeException("The database has already closed!");
        }
        return cursor;
    }

    /**
     * 查询礼物信息
     * @param sql
     * @param selectionArgs
     * @return
     * @throws Exception
     */

    public List<Recommendedgift> query2List(String sql, String[] selectionArgs) throws Exception {
        List<Recommendedgift> list = new ArrayList<>();
        if (sqLiteDatabase.isOpen()) {
            Cursor cursor = null;
            cursor = queryData2Cursor(sql, selectionArgs);
            Recommendedgift gift;
            if (cursor != null && cursor.getCount() > 0) {
                Log.e("DataBaseMAnger", "---------------query1-------------");
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {    // 采用循环的方式检索数据
                    gift = new Recommendedgift();
                    String title = cursor.getString(cursor.getColumnIndex("title"));
                    String description = cursor.getString(cursor.getColumnIndex("description"));
                    String imageurl = cursor.getString(cursor.getColumnIndex("imageurl"));
                    int shopping = cursor.getInt(cursor.getColumnIndex("shopping"));
                    int collection = cursor.getInt(cursor.getColumnIndex("collection"));
                    int id = cursor.getInt(cursor.getColumnIndex("id"));
                    int price = cursor.getInt(cursor.getColumnIndex("price"));
                    String kind = cursor.getString(cursor.getColumnIndex("kind"));
                    gift.setPhoto(Utils.getPhoto(imageurl));
                    gift.setCollection(collection);
                    gift.setDecribe(description);
                    gift.setId(id);
                    gift.setImageurl(imageurl);
                    gift.setKind(kind);
                    gift.setShopping(shopping);
                    gift.setTitle(title);
                    gift.setPrice(price);
                    list.add(gift);
                }
                cursor.close();
            }
        } else {
            throw new RuntimeException("The database has already closed!");
        }
        return list;
    }

    /**
     * 查询用户信息
     * @param sql
     * @param selectionArgs
     * @return
     * @throws Exception
     */
    public Map<String,String> queryUserinfo(String sql, String[] selectionArgs) throws Exception {
        Map<String, String> userMap = new HashMap<String, String>();
        if (sqLiteDatabase.isOpen()) {
            Cursor cursor = null;
            cursor = queryData2Cursor(sql, selectionArgs);
            if (cursor != null && cursor.getCount() > 0) {
                Log.e("DataBaseMAnger", "---------------query1-------------");
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {    // 采用循环的方式检索数据
                    String name = cursor.getString(cursor.getColumnIndex("Username"));
                    String sex = cursor.getString(cursor.getColumnIndex("sex"));
                    String phone = cursor.getString(cursor.getColumnIndex("phone"));
                    String signature = cursor.getString(cursor.getColumnIndex("signature"));
                    String id = cursor.getString(cursor.getColumnIndex("id"));
                    userMap.put("name",name );
                    userMap.put("signature",signature );
                    userMap.put("id",id );
                }
                cursor.close();
            }
        } else {
            throw new RuntimeException("The database has already closed!");
        }
        return userMap;
    }

    /**
     * 查询礼物信息
     * @param sql
     * @param selectionArgs
     * @return
     * @throws Exception
     */
    public List<Recommendedgift> queryList(String sql, String[] selectionArgs) throws Exception {
        List<Recommendedgift> list = new ArrayList<>();
        if (sqLiteDatabase.isOpen()) {
            Cursor cursor = null;
            cursor = queryData2Cursor(sql, selectionArgs);
            Recommendedgift gift;
            if (cursor != null && cursor.getCount() > 0) {
                Log.e("DataBaseMAnger", "---------------query-------------");
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {    // 采用循环的方式检索数据
                    gift = new Recommendedgift();
                    String title = cursor.getString(cursor.getColumnIndex("title"));
                    String description = cursor.getString(cursor.getColumnIndex("description"));
                    String imageurl = cursor.getString(cursor.getColumnIndex("titleimage"));
                    int id = cursor.getInt(cursor.getColumnIndex("id"));
                    String kind = cursor.getString(cursor.getColumnIndex("kind"));
                    String sort = cursor.getString(cursor.getColumnIndex("sort"));
                    gift.setPhoto(Utils.getPhoto(imageurl));
                    gift.setDecribe(description);
                    gift.setId(id);
                    gift.setImageurl(imageurl);
                    gift.setKind(kind);
                    gift.setTitle(title);
                    gift.setSort(sort);
                    list.add(gift);
                }
                cursor.close();
            }
        } else {
            throw new RuntimeException("The database has already closed!");
        }
        return list;
    }

    /**
     * 查询蛋糕和鲜花信息
     * @param sql
     * @param selectionArgs
     * @return
     * @throws Exception
     */
    public List<Cakeflower> querycakeflowerList(String sql, String[] selectionArgs) throws Exception {
        List<Cakeflower> list = new ArrayList<>();
        if (sqLiteDatabase.isOpen()) {
            Cursor cursor = null;
            cursor = queryData2Cursor(sql, selectionArgs);
            Cakeflower commdity;
            if (cursor != null && cursor.getCount() > 0) {
                Log.e("DataBaseMAnger", "---------------query-------------");
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {    // 采用循环的方式检索数据
                    commdity = new Cakeflower();
                    String name = cursor.getString(cursor.getColumnIndex("name"));
                    String kind = cursor.getString(cursor.getColumnIndex("kind"));
                    String imageurl = cursor.getString(cursor.getColumnIndex("photo"));
                    int id = cursor.getInt(cursor.getColumnIndex("id"));
                    int price = cursor.getInt(cursor.getColumnIndex("price"));
                    commdity.setPhoto(Utils.getPhoto(imageurl));
                    commdity.setId(id);
                    commdity.setKind(kind);
                    commdity.setName(name);
                    commdity.setPhotourl(imageurl);
                    commdity.setPrice(price);
                    list.add(commdity);
                }
                cursor.close();
            }
        } else {
            throw new RuntimeException("The database has already closed!");
        }
        return list;
    }

    /**
     *
     * @param sql 执行查询造作的SQL语句
     * @param selectionArgs 查询条件
     * @return 查询结果
     */
    public List<BrithDay> query3List(String sql, String[] selectionArgs)throws Exception
    {
        List<BrithDay> list = new ArrayList<>();
        if(sqLiteDatabase.isOpen())
        {
            Cursor cursor = null;
            cursor = queryData2Cursor(sql,selectionArgs);
            BrithDay brithDay;
            if(cursor !=null && cursor.getCount()>0)
            { Log.e("DataBaseMAnger","---------------query1-------------");
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {    // 采用循环的方式检索数据
                    brithDay=new BrithDay();
                    String name=cursor.getString(cursor.getColumnIndex("name"));
                    String phone=cursor.getString(cursor.getColumnIndex("phone"));
                    String photo=cursor.getString(cursor.getColumnIndex("photo"));
                    String brith1=cursor.getString(cursor.getColumnIndex("brith"));
//                    DateFormat format= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//                    Date brith= format.parse(brith1);
                    String remind1=cursor.getString(cursor.getColumnIndex("remind"));
//                    Date remind= format.parse(remind1);
                    String music=cursor.getString(cursor.getColumnIndex("music"));
                    String remarks=cursor.getString(cursor.getColumnIndex("remarks"));
                    brithDay.setTelephone(phone);
                    brithDay.setName(name);
                    brithDay.setPhoto(photo);
                    brithDay.setMusic(music);
                    brithDay.setBrithday(brith1);
                    brithDay.setRemind(remind1);
                    brithDay.setRemarks(remarks);
                    list.add(brithDay);
                }
                cursor.close();
            }
        }else
        {
            throw new RuntimeException("The database has already closed!");
        }
        return list;
    }

    /**
     * 将用户的生日信息存入数据库
     * @param brithday
     */
    public void insert(BrithDay brithday){
        String sql = "insert into brithday(name,phone,brith,remind,music,photo,remarks) values(?,?,?,?,?,?,?)";
        //wdb.execSQL("insert into user(name,age,sex) values('李清照',20,'女');");
        sqLiteDatabase.execSQL(sql,new Object[]{brithday.getName(),brithday.getTelephone(), brithday.getBrithday(),
                brithday.getRemind(),brithday.getMusic(),brithday.getPhoto(),brithday.getRemarks()});
        //ToastUtil.showToast(context, "增加");
    }
}
