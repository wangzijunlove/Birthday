package com.example.archermind.birthday.fragment;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.AddFriendActivity;
import com.example.archermind.birthday.R;
import com.example.archermind.birthday.adapter.BrithDayAdapter;
import com.example.archermind.birthday.adapter.SlideAdapter;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.BrithDay;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class Fragment1 extends Fragment implements View.OnClickListener {
    private String TAG = "Fragment birthday";
    private EditText editText_search;
    private ImageView imageView_add;
    private RecyclerView recyclerView_brithday;
    public static  BrithDayAdapter mbrithDayAdapter;
    public static List<BrithDay> list_brith = new ArrayList<>();
    private DatabaseManger manger;
    public static boolean flag_opretion = false;
    private final int REQUEST_PERMISSION = 1;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_manager, container, false );
        manger = new DatabaseManger(getContext());
        //权限申请
//        PermissionUtils.requestPermission(ManagerActivity.this, 1);
        try {
            list_brith = QueryData();
        } catch (Exception e) {
            e.printStackTrace();
        }
        SortList();
        //按钮增加，暂时不用
//        button_add = view.findViewById(R.id.btn_add);
//        button_add.setOnClickListener(this);
//        button_delete = view.findViewById(R.id.btn_delete);
//        button_delete.setOnClickListener(this);
        editText_search = view.findViewById(R.id.ettv_search);
        editText_search.setOnClickListener(this);
        imageView_add = view.findViewById(R.id.img_add);
        //imageView_add.setVisibility(View.VISIBLE);
        imageView_add.setOnClickListener(this);
        recyclerView_brithday = view.findViewById(R.id.recy_brithday);
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerView_brithday.setLayoutManager(manager);
        //过滤后的数据通过适配器展示
        mbrithDayAdapter = new BrithDayAdapter(list_brith, getContext(), new Fragment1.FilterListener() {
            @Override
            public void getFilterData(List<BrithDay> list) {
            }
        });
        recyclerView_brithday.addItemDecoration(new DividerItemDecoration(getContext(), 1));
        recyclerView_brithday.setItemAnimator(new DefaultItemAnimator());
        recyclerView_brithday.setAdapter(mbrithDayAdapter);
        return view;
    }


    /**
     *
     * 将数据库拿到的list数组中的数据通过时间算法给计算出生日距离今天还有多少天
     * 将最近的要过生日的这个人的姓名保存下来
     * 保存下来的姓名在首页显示即将过生日的人
     */
    private void  SortList (){
        for (int i = 0;i < list_brith.size(); i++){
            BrithDay birthday = list_brith.get(i);
            Date curDate = new Date(System.currentTimeMillis());
            Date Oldtime = null;
            String time = birthday.getBrithday();
            try {
                Oldtime = Utils.ConverToDate(time);
            } catch (Exception e) {
                e.printStackTrace();
            }
            int Timeflag = Utils.getTimeDifferent(Oldtime,curDate );
            list_brith.get(i).setTime(Timeflag);
        }
        Collections.sort(list_brith, new Comparator<BrithDay>() {
            @Override
            public int compare(BrithDay o1, BrithDay o2) {
                if(o1.getTime() > o2.getTime()){
                    return 1;
                }
                if(o1.getTime() == o2.getTime()){
                    return 0;
                }
                return -1;
            }
        });
        if(list_brith.size() > 0){
            Utils.savebirthdayInfo(getContext(), list_brith.get(0).getName());
        }

    }
    /**
     * 第一次进入到程序时，查询整个表中的数据，将数据赋给list,填充到适配器中
     * list在进行数据库的增删改时同时更新自己的数据，保持同步
     *
     * @return
     */

    private List<BrithDay> QueryData() {
        manger = new DatabaseManger(getContext());
        List<BrithDay> list = new ArrayList<>();
        String sql = "select *from brithday";
        try {
            list = manger.query3List(sql, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++)
            Log.e("Fragment birthday", "get name= " + list.get(i).getName() + "time" + list.get(i).getPhoto());
        manger.close();
        return list;
    }
    /**
     * 点击事件
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
//            case R.id.btn_add:
//                /**
//                 * 增加按钮的监听事件，跳转到增加界面
//                 * flag_opretion的标志控制复用的Activity是增加还是修改，false是增加
//                 *
//                 */
//                flag_opretion = false;
//                Intent intent1 = new Intent(getContext(), AddFriendActivity.class);
//                startActivity(intent1);
//                break;
//            case R.id.btn_delete:
//                //跳转到删除界面
////                Intent intent = new Intent(ManagerActivity.this, DeleteActivity.class);
////                startActivity(intent);
//                break;
            case R.id.ettv_search:
                /**
                 * 搜索功能，通过监听文本框的内容变化，过滤和文本内容相同的用户名
                 *
                 */
                editText_search.addTextChangedListener(new TextWatcher() {

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if (mbrithDayAdapter != null) {
                            mbrithDayAdapter.getFilter().filter(s);

                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                break;
            case R.id.img_add:
                flag_opretion = false;
                Intent intent5 = new Intent(getContext(), AddFriendActivity.class);
                startActivity(intent5);
                break;
        }

    }




    /**
     * 搜索功能的接口，通过次接口获取查找后的数据
     */
    public interface FilterListener {
        void getFilterData(List<BrithDay> list);// 获取过滤后的数据
    }


    @Override
    public void onStart() {
        super.onStart();
        mbrithDayAdapter.notifyDataSetChanged();
    }

    /**
     * Activity的生命周期，执行更新适配器，在增加和修改，删除的活动返回时执行
     * 效果是使得主界面的数据刷新
     */
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        mbrithDayAdapter.notifyDataSetChanged();
//
//        Log.e(TAG, "-----onRestart-----");
//    }
//
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        mbrithDayAdapter.closeMenu();
//    }


    @Override
    public void onStop() {
        super.onStop();
        mbrithDayAdapter.closeMenu();
    }

    /**
     * 权限的动态
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {


                        System.out.println("Permissions --> " + "Permission Granted: " + permissions[i]);
                    } else if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        System.out.println("Permissions --> " + "Permission Denied: " + permissions[i]);
                    }
                }
            }
            break;
            default: {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }

}
