package com.example.archermind.birthday.adapter;

import android.content.Context;
import android.os.Handler;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.archermind.birthday.Activity02;
import com.example.archermind.birthday.R;
import com.example.archermind.birthday.util.City;
import com.example.archermind.birthday.util.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
/**
 * create by 2018 12/10
 * Author :zwn
 *
 */
public class ListViewAdapter extends BaseAdapter  {
    private android.widget.ListView personList;
    private HashMap<String, Integer> alphaIndexer;// 存放存在的汉语拼音首字母和与之对应的列表位置
    private String[] sections;// 存放存在的汉语拼音首字母
    private TopViewHolder topViewHolder;
    private String lngCityName = "正在定位所在位置..";
    private LayoutInflater inflater;
    private List<City> list;
    final int VIEW_TYPE = 3;
    private Handler mHandler;
    private RecyclerView recyclerView;
    private PhotoAdapter cityAdapter;
    private Context mContext;
    private List<String> list_hot = new ArrayList<>();
    private String GpsCity ;

    /**
     *
     * @param context
     * @param list
     * @param handler
     * 构造方法，进行了初始化的操作
     */
    public ListViewAdapter(Context context, List<City> list, Handler handler) {
        this.inflater = LayoutInflater.from(context);
        this.list = list;
        mContext = context;
        mHandler = handler;
        Map<String,String> map = Utils.getInfo(mContext);  //SharePreferences获取保存的城市信息
        GpsCity = map.get("city");

        alphaIndexer = new HashMap<String, Integer>();
        sections = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            // 当前汉语拼音首字母
            String currentStr = getAlpha(list.get(i).getPinyi());
            // 上一个汉语拼音首字母，如果不存在为“ ”
            String previewStr = (i - 1) >= 0 ? getAlpha(list.get(i - 1)
                    .getPinyi()) : " ";
            if (!previewStr.equals(currentStr)) {
                String name = getAlpha(list.get(i).getPinyi());
                alphaIndexer.put(name, i);
                sections[i] = name;
            }
        }
        list_hot.add("上海");
        list_hot.add("北京");
        list_hot.add("广州");
        list_hot.add("深圳");
        list_hot.add("武汉");
        list_hot.add("上海");
        list_hot.add("西安");
        list_hot.add("天津");
        list_hot.add("南京");
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     *
     * @param position
     * @return
     * ListView进行多类型的Item显示的判断
     */
    @Override
    public int getItemViewType(int position) {
        // TODO Auto-generated method stub
        int type = 0;
        if (position == 1) {
            type = 1;
        }else if (position ==0)
        {
            type = 2;
        }
        return type;
    }

    @Override
    public int getViewTypeCount() {// 这里需要返回需要集中布局类型，总大小为类型的种数的下标
        return VIEW_TYPE;
    }

    /**
     *
     * @param position
     * @param convertView
     * @param parent
     * @return
     * getView进行数据的加载，这里使用的Item有三种类型
     * 1,GridView的网格布局
     * 2,显示一个TestView
     * 3,ListView的线性布局
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        int viewType = getItemViewType(position);
        if (viewType == 1) {  //加载网格布局
            if (convertView == null) {
                topViewHolder = new TopViewHolder();
                convertView = inflater.inflate(R.layout.hotcity_item,
                        null);
                topViewHolder.alpha = (TextView) convertView
                        .findViewById(R.id.hot_title);
                convertView.setTag(topViewHolder);
            } else {
                topViewHolder = (TopViewHolder) convertView.getTag();
            }
            recyclerView = convertView.findViewById(R.id.recy_hot);
            cityAdapter = new PhotoAdapter(mContext, list_hot);
            GridLayoutManager layoutManager = new GridLayoutManager(mContext, 3);
            recyclerView.setLayoutManager(layoutManager);
//            recyclerView.addItemDecoration(new GridDividerItemDecoration(10, 1));
            recyclerView.setAdapter(cityAdapter);
            //topViewHolder.name.setText(lngCityName);
            topViewHolder.alpha.setVisibility(View.VISIBLE);
            cityAdapter.setOnRecyclerViewItemListener(new PhotoAdapter.OnRecyclerViewItemListener() {
                @Override
                public void onItemClickListener(View view, int position) {  //单击事件
                    Log.e("热门城市",""+position);
                    String city = Utils.getInfo(mContext).get("city");
                    Utils.saveInfo(mContext, city, list_hot.get(position));
                    mHandler.sendEmptyMessage(3);
                }

                @Override
                public void onItemLongClickListener(View view, int position) {  //长点击事件

                }
            });
            topViewHolder.alpha.setText("热门城市");


        } else if (viewType == 2) {   //加载TestView
            final ShViewHolder shViewHolder;
            if (convertView == null) {
                shViewHolder = new ShViewHolder();
                convertView = inflater.inflate(R.layout.location_item, null);
                shViewHolder.location_name = (TextView) convertView
                        .findViewById(R.id.tv_location);
                convertView.setTag(shViewHolder);
            } else {
                shViewHolder = (ShViewHolder) convertView.getTag();
            }
            shViewHolder.location_name.setText("定位城市："+GpsCity);
        } else { //加载线性布局
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.list_item, null);
                holder = new ViewHolder();
                holder.alpha = (TextView) convertView
                        .findViewById(R.id.alpha);
                holder.name = (TextView) convertView
                        .findViewById(R.id.name);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            if (position >= 1) {
                holder.name.setText(list.get(position).getName());
                String currentStr = getAlpha(list.get(position).getPinyi());
                String previewStr = (position - 1) >= 0 ? getAlpha(list
                        .get(position - 1).getPinyi()) : " ";
                if (!previewStr.equals(currentStr)) {
                    holder.alpha.setVisibility(View.VISIBLE);
                    if (currentStr.equals("#")) {
                        currentStr = "全部城市";
                    }
                    holder.alpha.setText(currentStr);
                } else {
                    holder.alpha.setVisibility(View.GONE);
                }
            }
        }
        return convertView;
    }

    private class ViewHolder {
        TextView alpha; // 首字母标题
        TextView name; // 城市名字
    }

    private class TopViewHolder {
        TextView alpha; // 首字母标题
        TextView name; // 城市名字
    }
    private class ShViewHolder {
        TextView location_name;

    }

    /**
     *
     * @param str
     * @return
     * 获取城市的首字母
     */
    private String getAlpha(String str) {

        if (str.equals("-")) {
            return "#";
        }
        if (str == null) {
            return "#";
        }
        if (str.trim().length() == 0) {
            return "#";
        }
        char c = str.trim().substring(0, 1).charAt(0);
        // 正则表达式，判断首字母是否是英文字母
        Pattern pattern = Pattern.compile("^[A-Za-z]+$");
        if (pattern.matcher(c + "").matches()) {
            return (c + "").toUpperCase();
        } else {
            return "#";
        }
    }

    public GetCityName getclass() {
        return new GetCityName();
    }

    /**
     *
     */
    private class GetCityName implements Activity02.LocateIn {
        @Override
        public void getCityName(String name) {
            System.out.println(name);
            Log.e("------------", "" + name);
//            if (topViewHolder.name != null) {
            lngCityName = name;
            mHandler.sendEmptyMessage(2);
//             }
        }
    }
}
