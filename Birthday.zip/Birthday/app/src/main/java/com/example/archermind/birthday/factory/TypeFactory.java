package com.example.archermind.birthday.factory;

import android.view.View;

import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.BootomHomeBean;
import com.example.archermind.birthday.bean.ContentBean;
import com.example.archermind.birthday.bean.RecommendBean;
import com.example.archermind.birthday.bean.ShowdetailGiftBean;
import com.example.archermind.birthday.bean.ShowlistBean;
import com.example.archermind.birthday.bean.Sowingmap;
import com.example.archermind.birthday.viewholder.BaseViewHolder;


public interface TypeFactory {
  //  定义所有的返回类型
  int type(BannerBean bannerBean);

  int type(ContentBean contentBean);

  int type(Sowingmap sowingmap);

  int type(ShowlistBean showlistBean);

  int type(RecommendBean recommendBean);

  int type(BootomHomeBean bootomHomeBean);

  int type(ShowdetailGiftBean showdetailGiftBean);

  BaseViewHolder createViewHolder(int type, View itemView);
}

