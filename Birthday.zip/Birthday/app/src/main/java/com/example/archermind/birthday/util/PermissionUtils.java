package com.example.archermind.birthday.util;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class PermissionUtils {
     private static final int REQUEST_PERMISSION=1;
    private static String[] PERMISSIONS_CAMERA_AND_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.CAMERA
    };

    /**
     * 解决安卓6.0以上版本不能读取外部存储权限的问题
     * @param activity
     * @param requestCode
     * @return
     */
    public static void requestPermission(Activity activity, int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //读,写,相机权限
            int hasWritePermission = activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int hasReadPermission = activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int hasReadClaPermission = activity.checkSelfPermission(Manifest.permission.READ_CALENDAR);
            int hasWriteClaPermission=activity.checkSelfPermission(Manifest.permission.WRITE_CALENDAR);
            int hasCameraPermission = activity.checkSelfPermission(Manifest.permission.CAMERA);
            List<String> permissions = new ArrayList<String>();
            if (hasWritePermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            } else {
                Log.d("MainActivity ", "已经拥有写权限");
            }

            if (hasReadPermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);

            } else {
                Log.d("MainActivity ", "已经拥有读权限");
            }
            if (hasReadClaPermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.READ_CALENDAR);

            } else {
                Log.d("MainActivity ", "已经拥有读日历权限");
            }
            if (hasWriteClaPermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.WRITE_CALENDAR);

            } else {
                Log.d("MainActivity ", "已经拥有写日历权限");
            }
            if (hasCameraPermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.CAMERA);

            } else {
                Log.d("MainActivity ", "已经拥有相机权限");
            }

            if (!permissions.isEmpty()) {

                ActivityCompat.requestPermissions(activity, PERMISSIONS_CAMERA_AND_STORAGE,
                        REQUEST_PERMISSION);
            }
        }
    }
}
