package com.example.archermind.birthday.adapter;

import android.app.Notification;
import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import android.os.Handler;
/**
 * create by 2018 12/10
 * Author :zwn
 *
 */
public class GpsHelper {
    public AMapLocationClient mLocationClient = null;
    public AMapLocationListener mLocationListener = new MyAMapLocationListener();
    public AMapLocationClientOption mLocationOption = null;
    private Context mContext;
    private Handler mHandler;
    private Map<String,String> mapdata = new HashMap<>();

    /**
     *
     * @param context
     * @param handler
     * 构造方法，传入Handler将得到的位置信息发送出去
     */
    public GpsHelper (Context context, Handler handler){
        mContext = context;
        mHandler = handler;
        init();
    }

    /**
     * 封装的停止扫描位置方法
     */
    public void stopScan(){
        mLocationClient.stopLocation();
    }

    /**
     * 初始化操作
     *
     */
    private void init() {
        mLocationClient = new AMapLocationClient(mContext);
        mLocationClient.setLocationListener(mLocationListener);
        mLocationOption = new AMapLocationClientOption();
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        mLocationOption.setOnceLocation(false);
        mLocationOption.setOnceLocationLatest(true);
        mLocationOption.setNeedAddress(true);
        mLocationOption.setMockEnable(false);
        mLocationOption.setLocationCacheEnable(false);
        mLocationClient.setLocationOption(mLocationOption);
        mLocationClient.startLocation();
    }

    /**
     * 继承自高德地图的Api
     * Api提供的监听接口Listener返回当前的位置信息
     */
    private class MyAMapLocationListener implements AMapLocationListener {
        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            if (aMapLocation != null) {
                if (aMapLocation.getErrorCode() == 0) {
                    Log.e("hlper位置：", aMapLocation.getAddress());
                    StringBuffer  aa = new StringBuffer();
                    //mapdata.clear();
                    aa.append(aMapLocation.getCity());
                    aa.append("\n"+aMapLocation.getCountry());
                    aa.append("\n"+aMapLocation.getProvider());
                    aa.append("\n"+aMapLocation.getAoiName());
                    aa.append("\n"+aMapLocation.getProvince());
                    aa.append("\n"+aMapLocation.getLongitude());
                    aa.append("\n"+aMapLocation.getStreet());
                    aa.append("\n"+aMapLocation.getPoiName());
//                    list_data.add(aa.toString());
                    mapdata.put("City", aMapLocation.getCity());
                    mapdata.put("Province", aMapLocation.getProvince());
                    mapdata.put("Street",aMapLocation.getStreet() );
                    mapdata.put("Address",aMapLocation.getCity());
                   // Log.e("Street","" +mapdata.get("Street"));
                    Message Msg = new Message();
                    Bundle bundle1 = new Bundle();
                    bundle1.putSerializable("Address", (Serializable) mapdata);
                    Msg.what = 1;
                    Msg.setData(bundle1);
                    mHandler.sendMessage(Msg);
                } else {
                    Log.e("AmapError", "location Error, ErrCode:" + aMapLocation.getErrorCode() + ", errInfo:" + aMapLocation.getErrorInfo());
                }
            }
        }
    }
}
