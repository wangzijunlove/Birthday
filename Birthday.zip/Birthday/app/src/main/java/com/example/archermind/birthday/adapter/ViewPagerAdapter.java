package com.example.archermind.birthday.adapter;


import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

import com.example.archermind.birthday.viewholder.SowingmapViewHolder;

public class ViewPagerAdapter extends PagerAdapter {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return SowingmapViewHolder.imageResId.length;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		// TODO Auto-generated method stub
		return arg0 == arg1;
	}

	@Override
	public int getItemPosition(Object object) {
		// TODO Auto-generated method stub
		return super.getItemPosition(object);
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		// TODO Auto-generated method stub

		((ViewPager) container).removeView(SowingmapViewHolder.imageViews.get(position));
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		// TODO Auto-generated method stub
		((ViewPager) container).removeView(SowingmapViewHolder.imageViews.get(position));
		((ViewPager) container).addView(SowingmapViewHolder.imageViews
				.get(position));
		return SowingmapViewHolder.imageViews.get(position);
	}

}
