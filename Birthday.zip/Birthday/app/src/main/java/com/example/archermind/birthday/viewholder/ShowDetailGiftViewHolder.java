package com.example.archermind.birthday.viewholder;

import android.content.Context;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.archermind.birthday.R;
import com.example.archermind.birthday.adapter.DetailShowAdapter;
import com.example.archermind.birthday.adapter.ShowDetailGiftAdapter;
import com.example.archermind.birthday.bean.BannerBean;
import com.example.archermind.birthday.bean.ShowdetailGiftBean;
import com.example.archermind.birthday.util.Recommendedgift;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ShowDetailGiftViewHolder extends BaseViewHolder {
    @Bind(R.id.img_gift_showtitle)
    ImageView imageView;
    @Bind(R.id.tv_gift_showtitle)
    TextView textView_title;
    @Bind(R.id.tv_gift_showdecribe)
    TextView textView_decribe;
    @Bind(R.id.recy_gift_showcommodity)
    RecyclerView recyclerView;
    Context mContext;
    private Recommendedgift recommendedgift;
    private List<Recommendedgift> list_data = new ArrayList<>();
    public ShowDetailGiftViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
    @Override
    public void bindViewData(Object data) {
        Log.e("------------------", "绑定商品信息");
        mContext = ((ShowdetailGiftBean)data).getmContext();
        recommendedgift = ((ShowdetailGiftBean)data).getRecommendedgift();
        list_data = ((ShowdetailGiftBean)data).getList_data();
        imageView.setImageBitmap(recommendedgift.getPhoto());
        textView_title.setText(recommendedgift.getTitle());
        textView_decribe.setText(recommendedgift.getDecribe());
        LinearLayoutManager manager = new LinearLayoutManager(mContext);
        ShowDetailGiftAdapter adapter = new ShowDetailGiftAdapter(mContext,((ShowdetailGiftBean)data).getList_data());
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);


    }
}
