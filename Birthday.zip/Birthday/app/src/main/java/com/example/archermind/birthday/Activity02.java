package com.example.archermind.birthday;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.os.Handler;

public class Activity02 extends AppCompatActivity {
    private OverlayThread overlayThread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_02);
    }
    private class OverlayThread implements Runnable {
        @Override
        public void run() {
            tin.getCityName("上海");
        }

    }

    public void go(View v) {
        Intent intent = new Intent(Activity02.this, Activity01.class);
        startActivity(intent);
        overlayThread = new OverlayThread();
        Handler handler = new Handler();
        handler.postDelayed(overlayThread, 3000);
    }

    static LocateIn tin;

    public static void setLocateIn(LocateIn in) {
        tin = in;
    }

    public interface LocateIn {
        public void getCityName(String name);
    }
}
