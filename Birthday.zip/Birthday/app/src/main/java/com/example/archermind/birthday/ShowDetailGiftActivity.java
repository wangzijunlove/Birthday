
package com.example.archermind.birthday;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;

import com.example.archermind.birthday.adapter.MulitAdpter;
import com.example.archermind.birthday.bean.ShowdetailGiftBean;
import com.example.archermind.birthday.decorate.Visitable;
import com.example.archermind.birthday.sqlhepler.DatabaseManger;
import com.example.archermind.birthday.util.Recommendedgift;
import com.example.archermind.birthday.viewholder.BannerViewHolder;
import com.example.archermind.birthday.viewholder.RecommendViewHolder;
import com.example.archermind.birthday.viewholder.ShowlistViewHolder;

import java.util.ArrayList;
import java.util.List;

public class ShowDetailGiftActivity extends AppCompatActivity {
    public static final int TYPE_SHOW_GIFTDETAIL_MUST_GIFT = 0x09;
    public static final int TYPE_SHOW_GIFTDETAIL_FESTIVAL = 0x15;
    public static final int TYPE_SHOW_GIFT_RECOMMEND = 0x10;
    public static final int TYPE_SHOW_GIFT_SORT = 0x11;
    private ImageView imageView_back;

    List<Recommendedgift> list_data = new ArrayList<>();
    DatabaseManger manger;
    Recommendedgift recommendedgift;
    private RecyclerView recyclerView;
    private String TAG = "ShowDetailGiftActivity";
    public static Handler intentHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail_gift);
        recyclerView = findViewById(R.id.recy_gift_showdetailgift);
        Log.e("cvsvsdd", "" + list_data.size());
        imageView_back = findViewById(R.id.img_no1);
        imageView_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            Instrumentation inst = new Instrumentation();
                            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
        init();
        List<Visitable> beans = new ArrayList<>();
        beans.add(new ShowdetailGiftBean(list_data, ShowDetailGiftActivity.this, recommendedgift));
        MulitAdpter multiRecyclerAdapter = new MulitAdpter(beans);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(ShowDetailGiftActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(multiRecyclerAdapter);
    }


    /**
     * 根据不同信息加载不同的界面数据
     *
     */
    public void init() {
        Intent intent = getIntent();
        String sql = null;
        String kind = null;
        int flag = intent.getIntExtra("flag", -1);
        switch (flag) {
            case TYPE_SHOW_GIFT_RECOMMEND:
                recommendedgift = BannerViewHolder.getGift();
                kind = recommendedgift.getKind();
                manger = new DatabaseManger(ShowDetailGiftActivity.this);
                sql = "select *from commodity where kind = '" + kind + "' ";
                try {
                    list_data = manger.query2List(sql, null);
                    Log.e(TAG, "commodity查询成功" + list_data.size());
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "commodity查询失败");
                }
                manger.close();
                break;
            case TYPE_SHOW_GIFTDETAIL_MUST_GIFT:
                int position = intent.getIntExtra("position", -1);
                recommendedgift = RecommendViewHolder.getData().get(position);
                kind = recommendedgift.getKind();
                manger = new DatabaseManger(ShowDetailGiftActivity.this);
                sql = "select *from commodity where kind = '" + kind + "' ";
                try {
                    list_data = manger.query2List(sql, null);
                    Log.e(TAG, "commodity查询成功" + list_data.size());
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "commodity查询失败");
                }
                manger.close();
                break;
            case TYPE_SHOW_GIFTDETAIL_FESTIVAL:
                kind = "DIY";
                manger = new DatabaseManger(ShowDetailGiftActivity.this);
                sql = "select *from commodity where kind = '" + kind + "' ";
                try {
                    list_data = manger.query2List(sql, null);
                    Log.e(TAG, "commodity查询成功" + list_data.size());
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "commodity查询失败");
                }

                String sql1 = "select *from classification where sort = 'recommend' ";
                try {
                    List<Recommendedgift> list = manger.queryList(sql1, null);
                    recommendedgift = list.get(0);
                } catch (Exception e) {
                    Log.e(TAG, "classification查询失败");
                    e.printStackTrace();
                }

                manger.close();
                break;
            case TYPE_SHOW_GIFT_SORT:
                int index = intent.getIntExtra("position", -1);
                recommendedgift = ShowlistViewHolder.getData().get(index);
                kind = recommendedgift.getKind();
                manger = new DatabaseManger(ShowDetailGiftActivity.this);
                sql = "select *from commodity where kind = '" + kind + "' ";
                try {
                    list_data = manger.query2List(sql, null);
                    Log.e(TAG, "commodity查询成功" + list_data.size());
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "commodity查询失败");
                }
                manger.close();
        }
    }


//    @SuppressLint("HandlerLeak")
//    public  Handler GiftHandler = new Handler() {
//        public void handleMessage(Message msg) {
//            intentHandler = GiftHandler;
//            int type = msg.what;
//            switch (type) {
//                case TYPE_SHOW_GIFT_RECOMMEND:
//                    ArrayList result = msg.getData().getParcelableArrayList("data");
//                    recommendedgift = (Recommendedgift) result.get(0);
//                    String kind = recommendedgift.getKind();
//                    manger = new DatabaseManger(ShowDetailGiftActivity.this);
//                    String sql = "select *from commodity where kind = '"+kind+"' ";
//                    try {
//                        list_data = manger.query2List(sql, null);
//                        Log.e(TAG, "commodity查询成功"+list_data.size());
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                        Log.e(TAG, "commodity查询失败");
//                    }
//                    manger.close();
//                    break;
//                default:
//                    Log.d("-----", "should not get here!!!");
//                    break;
//            }
//        }
//    };


}
